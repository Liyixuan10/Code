
function [Best_FF3,Best_P3,Conv_curve3]=LAOA(N,M_Iter,LB,UB,Dim,F_obj,Function_name)
display('AOA Working');
%Two variables to keep the positions and the fitness value of the best-obtained solution

Best_P3=zeros(1,Dim);
Best_FF3=inf;
Conv_curve3=zeros(1,M_Iter);

%Initialize the positions of solution
X=initialization(N,Dim,UB,LB);
Xnew=X;
Ffun=zeros(1,size(X,1));% (fitness values)
Ffun_new=zeros(1,size(Xnew,1));% (fitness values)

MOP_Max=1;
MOP_Min=0.2;
C_Iter=1;
Alpha=5;
Mu=0.499;
a=0.5;
x(1)=rand;
y(1)=rand;
for i=1:size(X,1)
    Ffun(1,i)=F_obj(X(i,:)',Function_name);  %Calculate the fitness values of solutions
    if Ffun(1,i)<Best_FF3
        Best_FF3=Ffun(1,i);
        Best_P3=X(i,:);
    end
end



while C_Iter<M_Iter+1  %Main loop
    t = C_Iter;
    T = M_Iter;
    x(t+1)=sin(pi*(4*a*x(t)*(1-x(t)))+(1-a)*sin(pi*y(t)));
    y(t+1)=sin(pi*(4*a*y(t)*(1-y(t)))+(1-a)*sin(pi*x(t).^2));
   
     p=sqrt(x.^2+y.^2)
     v=atan2(y,x);

     MOP=(1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha)))*p(t+1)*0.8;
    
     MOA=(MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter))^(2)*v(t+1)*0.8; 
    
%      MOP=1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha))*p(t+1);
%    MOA=(MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter))^(2)*v(t+1);
   
    for i=1:size(X,1)   % if each of the UB and LB has a just value
        for j=1:size(X,2)
            r1=rand();
            if (size(LB,2)==1)
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P3(1,j)/(MOP+eps)*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j)=Best_P3(1,j)*MOP*((UB-LB)*Mu+LB);
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P3(1,j)-MOP*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j)=Best_P3(1,j)+MOP*((UB-LB)*Mu+LB);
                    end
                end
            end
            
            
            if (size(LB,2)~=1)   % if each of the UB and LB has more than one value
                r1=rand();
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P3(1,j)/(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j)=Best_P3(1,j)*MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P3(1,j)-MOP*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j)=Best_P3(1,j)+MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                end
            end
            
        end
        
        Flag_UB=Xnew(i,:)>UB; % check if they exceed (up) the boundaries
        Flag_LB=Xnew(i,:)<LB; % check if they exceed (down) the boundaries
        Xnew(i,:)=(Xnew(i,:).*(~(Flag_UB+Flag_LB)))+UB.*Flag_UB+LB.*Flag_LB;
        
        Ffun_new(1,i)=F_obj(Xnew(i,:)',Function_name);  % calculate Fitness function
        if Ffun_new(1,i)<Ffun(1,i)
            X(i,:)=Xnew(i,:);
            Ffun(1,i)=Ffun_new(1,i);
        end
        if Ffun(1,i)<Best_FF3
            Best_FF3=Ffun(1,i);
            Best_P3=X(i,:);
        end
        
    end
    
    
    %Update the convergence curve
    Conv_curve3(C_Iter)=Best_FF3;
    
    %Print the best solution details after every 50 iterations
    if mod(C_Iter,50)==0
        display(['At iteration ', num2str(C_Iter), ' the best solution fitness is ', num2str(Best_FF3)]);
    end
    
    C_Iter=C_Iter+1;  % incremental iteration
    
end







