
function [Best_F5,Best_P5,CNVG5]=RSA(N,T,lb,ub,dim,fobj,Function_name)
Best_P5=zeros(1,dim);           % best positions
Best_F5=inf;                    % best fitness
X=initializationRSA(N,dim,ub,lb); %Initialize the positions of solution
Xnew=zeros(N,dim);
CNVG5=zeros(1,T);               % Convergance array
 

t=1;                         % starting iteration
Alpha=0.1;                   % the best value 0.1
Beta=0.005;                  % the best value 0.005
Ffun=zeros(1,size(X,1));     % (old fitness values)
Ffun_new=zeros(1,size(X,1)); % (new fitness values)

for i=1:size(X,1) 
    Ffun(1,i)=fobj(X(i,:)',Function_name);   %Calculate the fitness values of solutions
        if Ffun(1,i)<Best_F5
            Best_F5=Ffun(1,i);
            Best_P5=X(i,:);
        end
end
  

while t<T+1  %Main loop %Update the Position of solutions
    ES=2*randn*(1-(t/T));  % Probability Ratio
    for i=2:size(X,1) 
        for j=1:size(X,2)  
                R=Best_P5(1,j)-X(randi([1 size(X,1)]),j)/((Best_P5(1,j))+eps);
                P=Alpha+(X(i,j)-mean(X(i,:)))/(Best_P5(1,j)*(ub-lb)+eps);
                Eta=Best_P5(1,j)*P;
                if (t<T/4)
                    Xnew(i,j)=Best_P5(1,j)-Eta*Beta-R*rand;    
                elseif (t<2*T/4 && t>=T/4)
                    Xnew(i,j)=Best_P5(1,j)*X(randi([1 size(X,1)]),j)*ES*rand;
                elseif (t<3*T/4 && t>=2*T/4)
                    Xnew(i,j)=Best_P5(1,j)*P*rand;
                else
                    Xnew(i,j)=Best_P5(1,j)-Eta*eps-R*rand;
                end
        end
            
            Flag_UB=Xnew(i,:)>ub; % check if they exceed (up) the boundaries
            Flag_LB=Xnew(i,:)<lb; % check if they exceed (down) the boundaries
            Xnew(i,:)=(Xnew(i,:).*(~(Flag_UB+Flag_LB)))+ub.*Flag_UB+lb.*Flag_LB;
            Ffun_new(1,i)=fobj(Xnew(i,:)',Function_name);
            if Ffun_new(1,i)<Ffun(1,i)
                X(i,:)=Xnew(i,:);
                Ffun(1,i)=Ffun_new(1,i);
            end
            if Ffun(1,i)<Best_F5
                Best_F5=Ffun(1,i);
                Best_P5=X(i,:);
            end
    end
  
    CNVG5(t)=Best_F5;  %Update the convergence curve

    if mod(t,50)==0  %Print the best universe details after every 50 iterations
        display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(Best_F5)]);
    end
     t=t+1;
end
end