
function [Best_FF1,Best_P1,CNVG1]=LSCAOA(N,T,lb,ub,dim,fobj,Function_name)
display('AOA Working');
% N=20;
% M_Iter=100;
% LB=-100;
% UB=100;
% Dim=10;
%Two variables to keep the positions and the fitness value of the best-obtained solution

Best_P1=zeros(1,dim);
Best_FF1=inf;
CNVG1=zeros(1,T);

%Initialize the positions of solution
X=initializationAOA(N,dim,ub,lb);
Xnew=X;
Ffun=zeros(1,size(X,1));% (fitness values)
Ffun_new=zeros(1,size(Xnew,1));% (fitness values)

MOP_Max=1;
MOP_Min=0.2;
C_Iter=1;
Alpha=5;
Mu=0.499;
x(1)=rand;
y(1)=rand;
r=0.7;
a=0.5;

for i=1:size(X,1)
    Ffun(1,i)=fobj(X(i,:)',Function_name);  %Calculate the fitness values of solutions
    if Ffun(1,i)<Best_FF1
        Best_FF1=Ffun(1,i);
        Best_P1=X(i,:);
    end
end
    
    

while C_Iter<T+1  %Main loop
    t = C_Iter;
    
%       x(t+1) =(sin(pi*(1.07*a*(7.86*x(t) - 23.31*(x(t)^2) + 28.75*(x(t)^3)) - 13.302875*(x(t)^4))) + (1-a)*sin(pi*y(t)));
%     y(t+1) = (sin(pi*(1.07*a*(7.86*y(t) - 23.31*(y(t)^2) + 28.75*(y(t)^3)) - 13.302875*(x(t)^4)))+(1-a)*sin(pi*x(t).^2))
%     p=sqrt(x.^2+y.^2)
%     v=atan2(y,x);
%      MOP=(1-((C_Iter)^(1/Alpha)/(T)^(1/Alpha)))*p(t+1);
%     
%      MOA=abs((MOP_Min+C_Iter*((MOP_Max-MOP_Min)/T))^(2)*v(t+1)*0.35); 

    
  x(t+1)=sin(pi*(a*cos(pi*(4*r*x(t)*(1-x(t))+(1-r)*sin(pi*x(t))-0.5)))+(1-a)*sin(pi*y(t)));
  y(t+1)=sin(pi*(a*cos(pi*(4*r*y(t)*(1-y(t))+(1-r)*sin(pi*y(t))-0.5)))+(1-a)*sin(pi*x(t).^2));
  
p=sqrt(x.^2+y.^2);
v=atan2(y,x);
    MOP=(1-((C_Iter)^(1/Alpha)/(T)^(1/Alpha)))*p(t+1)*0.85;   % Probability Ratio 
    MOA=(MOP_Min+C_Iter*((MOP_Max-MOP_Min)/T))^(2)*v(t+1)*0.65; %Accelerated function
   
    %Update the Position of solutions
    for i=1:size(X,1)   % if each of the UB and LB has a just value 
        for j=1:size(X,2)
           r1=rand();
            if (size(lb,2)==1)
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P1(1,j)/(MOP+eps)*((ub-lb)*Mu+lb);
                    else
                        Xnew(i,j)=Best_P1(1,j)*MOP*((ub-lb)*Mu+lb);
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P1(1,j)-MOP*((ub-lb)*Mu+lb);
                    else
                        Xnew(i,j)=Best_P1(1,j)+MOP*((ub-lb)*Mu+lb);
                    end
                end               
            end
            
           
            if (size(lb,2)~=1)   % if each of the UB and LB has more than one value 
                r1=rand();
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P1(1,j)/(MOP+eps)*((ub(j)-lb(j))*Mu+lb(j));
                    else
                        Xnew(i,j)=Best_P1(1,j)*MOP*((ub(j)-lb(j))*Mu+lb(j));
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P1(1,j)-MOP*((ub(j)-lb(j))*Mu+lb(j));
                    else
                        Xnew(i,j)=Best_P1(1,j)+MOP*((ub(j)-lb(j))*Mu+lb(j));
                    end
                end               
            end
            
        end
        
        Flag_UB=Xnew(i,:)>ub; % check if they exceed (up) the boundaries
        Flag_LB=Xnew(i,:)<lb; % check if they exceed (down) the boundaries
        Xnew(i,:)=(Xnew(i,:).*(~(Flag_UB+Flag_LB)))+ub.*Flag_UB+lb.*Flag_LB;
 
        Ffun_new(1,i)=fobj(Xnew(i,:)',Function_name);  % calculate Fitness function 
        if Ffun_new(1,i)<Ffun(1,i)
            X(i,:)=Xnew(i,:);
            Ffun(1,i)=Ffun_new(1,i);
        end
        if Ffun(1,i)<Best_FF1
        Best_FF1=Ffun(1,i);
        Best_P1=X(i,:);
        end
       
    end
    

    %Update the convergence curve
    CNVG1(C_Iter)=Best_FF1;
    
    %Print the best solution details after every 50 iterations
    if mod(C_Iter,50)==0
        display(['At iteration ', num2str(C_Iter), ' the best solution fitness is ', num2str(Best_FF1)]);
    end
     
    C_Iter=C_Iter+1;  % incremental iteration
   
end



