
function [Best_FF,Best_P,CNVG]=AOA(N,T,lb,ub,dim,fobj,Function_name)
display('AOA Working');
% N=20;
% M_Iter=100;
% LB=-100;
% UB=100;
% Dim=10;
%Two variables to keep the positions and the fitness value of the best-obtained solution

Best_P=zeros(1,dim);
Best_FF=inf;
CNVG=zeros(1,T);

%Initialize the positions of solution
X=initializationAOA(N,dim,ub,lb);
Xnew=X;
Ffun=zeros(1,size(X,1));% (fitness values)
Ffun_new=zeros(1,size(Xnew,1));% (fitness values)

MOP_Max=1;
MOP_Min=0.2;
C_Iter=1;
Alpha=5;
Mu=0.499;


for i=1:size(X,1)
    Ffun(1,i)=fobj(X(i,:)',Function_name);  %Calculate the fitness values of solutions
    if Ffun(1,i)<Best_FF
        Best_FF=Ffun(1,i);
        Best_P=X(i,:);
    end
end
    
    

while C_Iter<T+1  %Main loop
    MOP=1-((C_Iter)^(1/Alpha)/(T)^(1/Alpha));   % Probability Ratio 
    MOA=MOP_Min+C_Iter*((MOP_Max-MOP_Min)/T); %Accelerated function
   
    %Update the Position of solutions
    for i=1:size(X,1)   % if each of the UB and LB has a just value 
        for j=1:size(X,2)
           r1=rand();
            if (size(lb,2)==1)
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P(1,j)/(MOP+eps)*((ub-lb)*Mu+lb);
                    else
                        Xnew(i,j)=Best_P(1,j)*MOP*((ub-lb)*Mu+lb);
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P(1,j)-MOP*((ub-lb)*Mu+lb);
                    else
                        Xnew(i,j)=Best_P(1,j)+MOP*((ub-lb)*Mu+lb);
                    end
                end               
            end
            
           
            if (size(lb,2)~=1)   % if each of the UB and LB has more than one value 
                r1=rand();
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P(1,j)/(MOP+eps)*((ub(j)-lb(j))*Mu+lb(j));
                    else
                        Xnew(i,j)=Best_P(1,j)*MOP*((ub(j)-lb(j))*Mu+lb(j));
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P(1,j)-MOP*((ub(j)-lb(j))*Mu+lb(j));
                    else
                        Xnew(i,j)=Best_P(1,j)+MOP*((ub(j)-lb(j))*Mu+lb(j));
                    end
                end               
            end
            
        end
        
        Flag_UB=Xnew(i,:)>ub; % check if they exceed (up) the boundaries
        Flag_LB=Xnew(i,:)<lb; % check if they exceed (down) the boundaries
        Xnew(i,:)=(Xnew(i,:).*(~(Flag_UB+Flag_LB)))+ub.*Flag_UB+lb.*Flag_LB;
 
        Ffun_new(1,i)=fobj(Xnew(i,:)',Function_name);  % calculate Fitness function 
        if Ffun_new(1,i)<Ffun(1,i)
            X(i,:)=Xnew(i,:);
            Ffun(1,i)=Ffun_new(1,i);
        end
        if Ffun(1,i)<Best_FF
        Best_FF=Ffun(1,i);
        Best_P=X(i,:);
        end
       
    end
    

    %Update the convergence curve
    CNVG(C_Iter)=Best_FF;
    
    %Print the best solution details after every 50 iterations
    if mod(C_Iter,50)==0
        display(['At iteration ', num2str(C_Iter), ' the best solution fitness is ', num2str(Best_FF)]);
    end
     
    C_Iter=C_Iter+1;  % incremental iteration
   
end



