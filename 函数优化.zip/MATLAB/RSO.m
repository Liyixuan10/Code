function[Score7,Position7,CNVG7]=RSO(N,T,lb,ub,dim,fobj,Function_name)
Position7=zeros(1,dim);
Score7=inf; 
Positions=init(N,dim,ub,lb);
CNVG7=zeros(1,T);
l=0;
x = 1;
y = 5;
R = floor((y-x).*rand(1,1) + x);
while l<T
    for i=1:size(Positions,1)  
        
        Flag4Upper_bound=Positions(i,:)>ub;
        Flag4Lower_bound=Positions(i,:)<lb;
        Positions(i,:)=(Positions(i,:).*(~(Flag4Upper_bound+Flag4Lower_bound)))+ub.*Flag4Upper_bound+lb.*Flag4Lower_bound;               
        
        fitness=fobj(Positions(i,:)',Function_name);
        
        if fitness<Score7 
            Score7=fitness; 
            Position7=Positions(i,:);
        end
        
    end
   
    A=R-l*((R)/T); 
    
    for i=1:size(Positions,1)
        for j=1:size(Positions,2)     
            C=2*rand();          
            P_vec=A*Positions(i,j)+abs(C*((Position7(j)-Positions(i,j))));                   
            P_final=Position7(j)-P_vec;
            Positions(i,j)=P_final;
            
        end
    end
    l=l+1;    
    CNVG7(l)=Score7;
end
