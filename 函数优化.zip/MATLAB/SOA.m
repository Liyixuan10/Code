function[SOABest_score2,SOABest_pos2,CNVG2]=SOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)

lowerbound = lb;
upperbound = ub;
dimension = dim;
lowerbound=ones(1,dimension).*(lowerbound);                              % Lower limit for variables
upperbound=ones(1,dimension).*(upperbound);                              % Upper limit for variables
for i=1:dimension
    X(:,i) = lowerbound(i)+rand(SearchAgents_no,1).*(upperbound(i) - lowerbound(i));                          % Initial population
end

for i =1:SearchAgents_no
    L=X(i,:);
%     fit(i)=fitness(L);
    fit(i) = fobj(L',Function_name);
end
%

for t=1:Max_iteration
    % update the best member and worst member
    [best , blocation]=min(fit);
    if t==1
        Xbest=X(blocation,:);                                           % Optimal location
        fbest=best;                                           % The optimization objective function
    elseif best<fbest
        fbest=best;
        Xbest=X(blocation,:);
    end
    
    
    % update SOA population
    
    for i=1:SearchAgents_no
        
        % Phase 1: Exploration
        %
        K=find(fit<fit(i));
        if size(K,2)~=0
            KK=randperm(size(K,2),1);
        else
            K=i;
            KK=1;
        end
        K=K(KK);
        expert=X(K,:);
        %
        if rand <0.5
            I=round(1+rand(1,1));
            RAND=rand(1,1);
        else
            I=round(1+rand(1,dimension));
            RAND=rand(1,dimension);
        end
        X_P1(i,:)=X(i,:)+RAND .* (expert-I.*X(i,:)); % Eq. (3)
        X_P1(i,:) = max(X_P1(i,:),lowerbound);X_P1(i,:) = min(X_P1(i,:),upperbound);
        
        % update position based on Eq (4)
        L=X_P1(i,:);
        F_P1(i) = fobj(L',Function_name);
%         F_P1(i)=fitness(L);
        if F_P1(i)<fit(i)
            X(i,:) = X_P1(i,:);
            fit(i) = F_P1(i);
        end
        %
        % END Phase 1: Exploration (global search)
        
    end% END for i=1:SearchAgents
    
    %
%      Phase 2: exploitation (local search)
    for i=1:SearchAgents_no
        
        if rand<0.5
            X_P2(i,:)= X(i,:)+ ((1-2*rand(1,dimension))/t).*X(i,:);% Eq.(5)
            X_P2(i,:) = max(X_P2(i,:),lowerbound);X_P2(i,:) = min(X_P2(i,:),upperbound);
        else
            X_P2(i,:)= X(i,:)+ lowerbound./t+rand(1,1).*(upperbound./t-lowerbound./t);%Eq(5)
            X_P2(i,:) = max(X_P2(i,:),lowerbound./t);X_P2(i,:) = min(X_P2(i,:),upperbound./t);
            X_P2(i,:) = max(X_P2(i,:),lowerbound);X_P2(i,:) = min(X_P2(i,:),upperbound);
        end
        
        % update position based on Eq (6)
        L=X_P2(i,:);
%         F_P2(i)=fitness(L);
        F_P2(i) = fobj(L',Function_name);
        if F_P2(i)<fit(i)
            X(i,:) = X_P2(i,:);
            fit(i) = F_P2(i);
        end
        %
        
    end % END for i=1:SearchAgents
    
    % END Phase 2: exploitation (local search)
   CNVG2(t)=fbest;
%    fprintf('\nIteration %d Best (SOA)= %f',t,SOA_curve(t))
end% END for t=1:Max_iterations
SOABest_score2=fbest;
SOABest_pos2=Xbest;
% SOA_curve(t)=fbest;
% fprintf('\nIteration %d Best (HBA)= %f',t,SOA_curve(t))
end

