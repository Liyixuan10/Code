%%
%�����㷨�ο�����https://mianbaoduo.com/o/liang
%�����㷨ԭ�� https://blog.csdn.net/weixin_46204734/category_11458421.html?spm=1001.2014.3001.5482
%%
close all
clear 
clc
SearchAgents_no=30; %��Ⱥ��С
Function_name=12;     %���Ժ���1-12
Max_iteration=1000;  %����������
lb=-100;             %�����½�
ub=100;              %�����Ͻ�
dim=10;              %ά�� 10/20
fobj=str2func('cec22_test_func');  %�����ַ��������캯�����
j=30;
for i=1:j
[Best_FF,Best_P,CNVG]=AOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
[Best_FF1,Best1_P,CNVG1]=LSCAOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
[Best_FF2,Best2_P,CNVG2]=STCAOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
[Best_FF3,Best_P3,CNVG3]=TLCAOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
[Best_FF4,Best_P4,CNVG4]=SGCAOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
[Best_FF5,Best_P5,CNVG5]=LGCAOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
[Best_FF6,Best_P6,CNVG6]=SSCAOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
% [Best_FF7,Best_P7,CNVG7]=SGAOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name)
% [best_score1,best_pos1,CNVG1]=GRO(dim,SearchAgents_no,Max_iteration,lb,ub,fobj,Function_name );
% [best_score2,best_pos2,CNVG2]=LGRO(dim,SearchAgents_no,Max_iteration,lb,ub,fobj,Function_name );
% [best_pos3,best_score3,CNVG3]=BAT(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name);
% [best_pos4,best_score4,CNVG4]=LBAT(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name);
%  [best_score4,best_pos4,CNVG4]=GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name);
%   [best_score5,best_pos5,CNVG5]=GROGWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj,Function_name);
%  [best_score6 , best_pos6,CNVG6 ] = SSA(SearchAgents_no, Max_iteration,lb,ub,dim,fobj,Function_name);

    c(i,:)=CNVG;
    d(i,:)=CNVG1;
    e(i,:)=CNVG2;
    f(i,:)=CNVG3;
    g(i,:)=CNVG4;
    h(i,:)=CNVG5;
    m(i,:)=CNVG6;
   
end
sum=0;
sum1=0;
sum2=0;
sum3=0;
sum4=0;
sum5=0;
sum6=0;

for i=1:j
    sum=sum+c(i,:);
    sum1=sum1+d(i,:);
    sum2=sum2+e(i,:);
    sum3=sum3+f(i,:);
    sum4=sum4+g(i,:);
    sum5=sum5+h(i,:);
    sum6=sum6+m(i,:);
   
end

CNVG=sum/j;
CNVG1=sum1/j;
CNVG2=sum2/j;
CNVG3=sum3/j;
CNVG4=sum4/j;
CNVG5=sum5/j;
CNVG6=sum6/j;


semilogy(CNVG,'Marker','o','markerindices',(1:100:1000),'Color','b','LineWidth',0.75);
hold on
semilogy(CNVG1,'Marker','x','markerindices',(1:100:1000),'Color','r','LineWidth',0.75);
hold on
semilogy(CNVG2,'Marker','p','markerindices',(1:100:1000),'Color','k','LineWidth',0.75);
hold on
semilogy(CNVG3,'Marker','*','markerindices',(1:100:1000),'Color','g','LineWidth',0.75);
hold on
semilogy(CNVG4,'Marker','+','markerindices',(1:100:1000),'Color','m','LineWidth',0.75);
hold on
semilogy(CNVG5,'Marker','>','markerindices',(1:100:1000),'Color','c','LineWidth',0.75);
hold on
semilogy(CNVG6,'Marker','diamond','markerindices',(1:100:1000),'Color','#D95319','LineWidth',0.75);
hold on


y=std(c(:,1000));
y1=std(d(:,1000));
y2=std(e(:,1000));
y3=std(f(:,1000));
y4=std(g(:,1000));
y5=std(h(:,1000));
y6=std(m(:,1000));


Mean_y=min(CNVG);
Mean_y1=min(CNVG1);
Mean_y2=min(CNVG2);
Mean_y3=min(CNVG3);
Mean_y4=min(CNVG4);
Mean_y5=min(CNVG5);
Mean_y6=min(CNVG6);


Min_y=min(c(:,1000));
Min_y1=min(d(:,1000));
Min_y2=min(e(:,1000));
Min_y3=min(f(:,1000));
Min_y4=min(g(:,1000));
Min_y5=min(h(:,1000));
Min_y6=min(m(:,1000));


title('Convergence curve')
xlabel('Iteration');
ylabel('Best fitness obtained so far');
axis tight
grid off
box on
legend('AOA','LSCAOA','STCAOA','TLCAOA','SGCAOA','LGCAOA','SSCAOA')

