
function [Best_FF2,Best_P2,Conv_curve2]=PAOA(N,M_Iter,LB,UB,Dim,F_obj,Function_name)
display('AOA Working');
%Two variables to keep the positions and the fitness value of the best-obtained solution

Best_P2=zeros(1,Dim);
Best_FF2=inf;
Conv_curve2=zeros(1,M_Iter);

%Initialize the positions of solution
X=initialization(N,Dim,UB,LB);
Xnew=X;
Ffun=zeros(1,size(X,1));% (fitness values)
Ffun_new=zeros(1,size(Xnew,1));% (fitness values)

MOP_Max=1;
MOP_Min=0.2;
C_Iter=1;
Alpha=5;
Mu=0.499;
a=0.5;
x(1)=rand;
y(1)=rand;
P=0.4;
for i=1:size(X,1)
    Ffun(1,i)=F_obj(X(i,:)',Function_name);  %Calculate the fitness values of solutions
    if Ffun(1,i)<Best_FF2
        Best_FF2=Ffun(1,i);
        Best_P2=X(i,:);
    end
end



while C_Iter<M_Iter+1  %Main loop
    t = C_Iter;
    T = M_Iter;
        if x(t)>=0 && x(t)<P
        x(t+1)=sin(pi*(a*x(t)/P)+(1-a)*sin(pi*y(t)));
    end
    if x(t)>=P && x(t)<0.5
        x(t+1)=sin(pi*(a*(x(t)-P)/(0.5-P))+(1-a)*sin(pi*y(t)));
    end
    
    if x(t)>=0.5 && x(t)<1-P
        x(t+1)=sin(pi*(a*(1-P-x(t))/(0.5-P))+(1-a)*sin(pi*y(t)));
    end
    if x(t)>=1-P && x(t)<1
        x(t+1)=sin(pi*(a*(1-x(t))/P)+(1-a)*sin(pi*y(t)));
    end
    
    if y(t)>=0 && y(t)<P
        y(t+1)=sin(pi*(a*y(t)/P)+(1-a)*sin(pi*x(t).^2));
    end
     if y(t)>=P && y(t)<0.5
        y(t+1)=sin(pi*(a*(y(t)-P)/(0.5-P))+(1-a)*sin(pi*x(t).^2));
     end
     if y(t)>=0.5 && y(t)<1-P
        y(t+1)=sin(pi*(a*(1-P-y(t))/(0.5-P))+(1-a)*sin(pi*x(t).^2));
     end
    if y(t)>=1-P && y(t)<1
        y(t+1)=sin(pi*(a*(1-y(t))/P)+(1-a)*sin(pi*x(t).^2));
    end
     p=sqrt(x.^2+y.^2)
     v=atan2(y,x);
    
     MOP=(1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha)))*p(t+1)*0.75;
    
     MOA=(MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter))^(2)*v(t+1)*0.8; 
 
 
%         MOP=1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha))*p(t+1);   % Probability Ratio
%      MOA=(MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter))^(2)*v(t+1); %Accelerated function
    for i=1:size(X,1)   % if each of the UB and LB has a just value
        for j=1:size(X,2)
            r1=rand();
            if (size(LB,2)==1)
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P2(1,j)/(MOP+eps)*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j)=Best_P2(1,j)*MOP*((UB-LB)*Mu+LB);
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P2(1,j)-MOP*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j)=Best_P2(1,j)+MOP*((UB-LB)*Mu+LB);
                    end
                end
            end
            
            
            if (size(LB,2)~=1)   % if each of the UB and LB has more than one value
                r1=rand();
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_P2(1,j)/(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j)=Best_P2(1,j)*MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_P2(1,j)-MOP*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j)=Best_P2(1,j)+MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                end
            end
            
        end
        
        Flag_UB=Xnew(i,:)>UB; % check if they exceed (up) the boundaries
        Flag_LB=Xnew(i,:)<LB; % check if they exceed (down) the boundaries
        Xnew(i,:)=(Xnew(i,:).*(~(Flag_UB+Flag_LB)))+UB.*Flag_UB+LB.*Flag_LB;
        
        Ffun_new(1,i)=F_obj(Xnew(i,:)',Function_name);  % calculate Fitness function
        if Ffun_new(1,i)<Ffun(1,i)
            X(i,:)=Xnew(i,:);
            Ffun(1,i)=Ffun_new(1,i);
        end
        if Ffun(1,i)<Best_FF2
            Best_FF2=Ffun(1,i);
            Best_P2=X(i,:);
        end
        
    end
    
    
    %Update the convergence curve
    Conv_curve2(C_Iter)=Best_FF2;
    
    %Print the best solution details after every 50 iterations
    if mod(C_Iter,50)==0
        display(['At iteration ', num2str(C_Iter), ' the best solution fitness is ', num2str(Best_FF2)]);
    end
    
    C_Iter=C_Iter+1;  % incremental iteration
    
end







