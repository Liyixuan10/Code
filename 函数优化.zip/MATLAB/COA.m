function[Best_score2,Best_pos2,CNVG2]=COA(N,T,lb,ub,dim,fobj,Function_name)

lb=ones(1,dim).*(lb);                              % Lower limit for variables
ub=ones(1,dim).*(ub);                              % Upper limit for variables

%% INITIALIZATION
for i=1:dim
    X(:,i) = lb(i)+rand(N,1).*(ub(i) - lb(i));                          % Initial population
end

for i =1:N
    L=X(i,:);
    fit(i)=fobj(L',Function_name);
end
%%

for t=1:T
    %% update the best condidate solution
    [best , location]=min(fit);
    if t==1
        Xbest=X(location,:);                                           % Optimal location
        fbest=best;                                           % The optimization objective function
    elseif best<fbest
        fbest=best;
        Xbest=X(location,:);
    end



    %%
    for i=1:N/2

        %% Phase1: Hunting and attacking strategy on iguana (Exploration Phase)
        iguana=Xbest;
        I=round(1+rand(1,1));

        X_P1(i,:)=X(i,:)+rand(1,1) .* (iguana-I.*X(i,:)); % Eq. (4)
        X_P1(i,:) = max(X_P1(i,:),lb);X_P1(i,:) = min(X_P1(i,:),ub);

        % update position based on Eq (7)
        L=X_P1(i,:);
        F_P1(i)=fobj(L',Function_name);
        if(F_P1(i)<fit(i))
            X(i,:) = X_P1(i,:);
            fit(i) = F_P1(i);
        end

    end
    %%

    for i=1+N/2 :N

        iguana=lb+rand.*(ub-lb); %Eq(5)
        L=iguana;
        F_HL=fobj(L',Function_name);
        I=round(1+rand(1,1));

        if fit(i)> F_HL
            X_P1(i,:)=X(i,:)+rand(1,1) .* (iguana-I.*X(i,:)); % Eq. (6)
        else
            X_P1(i,:)=X(i,:)+rand(1,1) .* (X(i,:)-iguana); % Eq. (6)
        end
        X_P1(i,:) = max(X_P1(i,:),lb);X_P1(i,:) = min(X_P1(i,:),ub);

        % update position based on Eq (7)
        L=X_P1(i,:);
        F_P1(i)=fobj(L',Function_name);
        if(F_P1(i)<fit(i))
            X(i,:) = X_P1(i,:);
            fit(i) = F_P1(i);
        end
    end
    %% END Phase1: Hunting and attacking strategy on iguana (Exploration Phase)

    %%

    %% Phase2: The process of escaping from predators (Exploitation Phase)
    for i=1:N
        LO_LOCAL=lb/t;% Eq(9)
        HI_LOCAL=ub/t;% Eq(10)

        X_P2(i,:)=X(i,:)+(1-2*rand).* (LO_LOCAL+rand(1,1) .* (HI_LOCAL-LO_LOCAL)); % Eq. (8)
        X_P2(i,:) = max(X_P2(i,:),LO_LOCAL);X_P2(i,:) = min(X_P2(i,:),HI_LOCAL);

        % update position based on Eq (11)
        L=X_P2(i,:);
        F_P2(i)=fobj(L',Function_name);
        if(F_P2(i)<fit(i))
            X(i,:) = X_P2(i,:);
            fit(i) = F_P2(i);
        end

    end
    %% END Phase2: The process of escaping from predators (Exploitation Phase)


    best_so_far(t)=fbest;
    average(t) = mean (fit);

end
Best_score2=fbest;
Best_pos2=Xbest;
CNVG2=best_so_far;
end

