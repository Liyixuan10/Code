function [MRFOBestF,MRFOBestX,MRFOTCNVG6,MRFO_PL,MRFO_PTotal]=MRFO(Dim,N,M_Iter,LB,UB,f20_ELD_mobjective)

%          [Low,Up,Dim]=FunRange(F_index); 

    for i=1:N   
        PopPos(i,:)=rand(1,Dim).*(UB-LB)+LB;
        PopFit(i)=f20_ELD_mobjective(PopPos(i,:));   
    end
       MRFOBestF=inf;
       MRFOBestX=[];

    for i=1:N
        if PopFit(i)<=MRFOBestF
           MRFOBestF=PopFit(i);
           MRFOBestX=PopPos(i,:);
        end
    end

       MRFOTCNVG6=zeros(M_Iter,1);


for It=1:M_Iter  
     Coef=It/M_Iter; 
     
       if rand<0.5
          r1=rand;                         
          Beta=2*exp(r1*((M_Iter-It+1)/M_Iter))*(sin(2*pi*r1));    
          if  Coef>rand                                                      
              newPopPos(1,:)=MRFOBestX+rand(1,Dim).*(MRFOBestX-PopPos(1,:))+Beta*(MRFOBestX-PopPos(1,:)); %Equation (4)
          else
              IndivRand=rand(1,Dim).*(UB-LB)+LB;                                
              newPopPos(1,:)=IndivRand+rand(1,Dim).*(IndivRand-PopPos(1,:))+Beta*(IndivRand-PopPos(1,:)); %Equation (7)         
          end              
       else 
            Alpha=2*rand(1,Dim).*(-log(rand(1,Dim))).^0.5;           
            newPopPos(1,:)=PopPos(1,:)+rand(1,Dim).*(MRFOBestX-PopPos(1,:))+Alpha.*(MRFOBestX-PopPos(1,:)); %Equation (1)
       end
     
    for i=2:N
        if rand<0.5
           r1=rand;                         
           Beta=2*exp(r1*((M_Iter-It+1)/M_Iter))*(sin(2*pi*r1));    
             if  Coef>rand                                                      
                 newPopPos(i,:)=MRFOBestX+rand(1,Dim).*(PopPos(i-1,:)-PopPos(i,:))+Beta*(MRFOBestX-PopPos(i,:)); %Equation (4)
             else
                 IndivRand=rand(1,Dim).*(UB-LB)+LB;                                
                 newPopPos(i,:)=IndivRand+rand(1,Dim).*(PopPos(i-1,:)-PopPos(i,:))+Beta*(IndivRand-PopPos(i,:));  %Equation (7)       
             end              
        else
            Alpha=2*rand(1,Dim).*(-log(rand(1,Dim))).^0.5;           
            newPopPos(i,:)=PopPos(i,:)+rand(1,Dim).*(PopPos(i-1,:)-PopPos(i,:))+Alpha.*(MRFOBestX-PopPos(i,:)); %Equation (1)
       end         
    end
         
           for i=1:N        
%                for j=1:1
%             if newPopPos(i,j)<100
%                 newPopPos(i,j)=100;
%             end
%             if newPopPos(i,j)>210&&newPopPos(i,j)<225
%                 newPopPos(i,j)=210;
%             end
%             if newPopPos(i,j)>225&&newPopPos(i,j)<240
%                 newPopPos(i,j)=240;
%             end
%             if newPopPos(i,j)>350&&newPopPos(i,j)<365
%                 newPopPos(i,j)=350;
%             end
%             if newPopPos(i,j)>365&&newPopPos(i,j)<380
%                 newPopPos(i,j)=380;
%             end
%             if newPopPos(i,j)>500
%                 newPopPos(i,j)=500;
%             end
%              %x(i,j)=round(x(i,j));
%               end
%          for j=2:2
%              if newPopPos(i,j)<50
%                 newPopPos(i,j)=50;
%              end
%              if newPopPos(i,j)>90&&newPopPos(i,j)<100
%                 newPopPos(i,j)=90;
%             end
%             if newPopPos(i,j)>100&&newPopPos(i,j)<110
%                 newPopPos(i,j)=110;
%             end
%             if newPopPos(i,j)>140&&newPopPos(i,j)<150
%                 newPopPos(i,j)=140;
%             end
%             if newPopPos(i,j)>150&&newPopPos(i,j)<160
%                 newPopPos(i,j)=160;
%             end
%             if newPopPos(i,j)>200
%                 newPopPos(i,j)=200;
%             end
%             %x(i,j)=round(x(i,j));
%          end
%          for j=3:3
%              if newPopPos(i,j)<80
%                 newPopPos(i,j)=80;
%              end
%              if newPopPos(i,j)>90&&newPopPos(i,j)<100
%                 newPopPos(i,j)=90;
%             end
%             if newPopPos(i,j)>100&&newPopPos(i,j)<110
%                 newPopPos(i,j)=110;
%             end
%             if newPopPos(i,j)>140&&newPopPos(i,j)<150
%                 newPopPos(i,j)=140;
%             end
%             if newPopPos(i,j)>150&&newPopPos(i,j)<160
%                 newPopPos(i,j)=160;
%             end
%             if newPopPos(i,j)>300
%                 newPopPos(i,j)=300;
%             end
%             %x(i,j)=round(x(i,j));
%          end
%          for j=4:4
%              if newPopPos(i,j)<50
%                 newPopPos(i,j)=50;
%              end
%              if newPopPos(i,j)>80&&newPopPos(i,j)<85
%                 newPopPos(i,j)=80;
%             end
%             if newPopPos(i,j)>85&&newPopPos(i,j)<90
%                 newPopPos(i,j)=90;
%             end
%             if newPopPos(i,j)>110&&newPopPos(i,j)<115
%                 newPopPos(i,j)=110;
%             end
%             if newPopPos(i,j)>115&&newPopPos(i,j)<120
%                 newPopPos(i,j)=120;
%             end
%             if newPopPos(i,j)>150
%                 newPopPos(i,j)=150;
%             end
%             %x(i,j)=round(x(i,j));
%          end
%          for j=5:5
%              if newPopPos(i,j)<50
%                 newPopPos(i,j)=50;
%              end
%              if newPopPos(i,j)>90&&newPopPos(i,j)<100
%                 newPopPos(i,j)=90;
%             end
%             if newPopPos(i,j)>100&&newPopPos(i,j)<110
%                 newPopPos(i,j)=110;
%             end
%             if newPopPos(i,j)>140&&newPopPos(i,j)<145
%                 newPopPos(i,j)=140;
%             end
%             if newPopPos(i,j)>145&&newPopPos(i,j)<150
%                 newPopPos(i,j)=150;
%             end
%             if newPopPos(i,j)>200
%                 newPopPos(i,j)=200;
%             end
%             %x(i,j)=round(x(i,j));
%          end
%        for j=6:6
%              if newPopPos(i,j)<50
%                 newPopPos(i,j)=50;
%              end
%              if newPopPos(i,j)>75&&newPopPos(i,j)<80
%                 newPopPos(i,j)=75;
%             end
%             if newPopPos(i,j)>80&&newPopPos(i,j)<85
%                 newPopPos(i,j)=85;
%             end
%             if newPopPos(i,j)>100&&newPopPos(i,j)<102
%                 newPopPos(i,j)=100;
%             end
%             if newPopPos(i,j)>102&&newPopPos(i,j)<105
%                 newPopPos(i,j)=105;
%             end
%             if newPopPos(i,j)>120
%                 newPopPos(i,j)=120;
%             end
%             %x(i,j)=round(x(i,j));
%        end
        for j=1:1
            if newPopPos(i,j)<150
                newPopPos(i,j)=150;
            end
            if newPopPos(i,j)>600
                newPopPos(i,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if newPopPos(i,j)<50
                newPopPos(i,j)=50;
             end
            if newPopPos(i,j)>200
                newPopPos(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if newPopPos(i,j)<50
                newPopPos(i,j)=50;
             end
            if newPopPos(i,j)>160
                newPopPos(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if newPopPos(i,j)<20
                newPopPos(i,j)=20;
             end
            if newPopPos(i,j)>100
                newPopPos(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if newPopPos(i,j)<25
                newPopPos(i,j)=25;
             end
            if newPopPos(i,j)>125
                newPopPos(i,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if newPopPos(i,j)<50
                newPopPos(i,j)=50;
             end
            if newPopPos(i,j)>150
                newPopPos(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if newPopPos(i,j)<50
                newPopPos(i,j)=50;
             end
            if newPopPos(i,j)>200
                newPopPos(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if newPopPos(i,j)<30
                newPopPos(i,j)=30;
             end
            if newPopPos(i,j)>150
                newPopPos(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if newPopPos(i,j)<100
                newPopPos(i,j)=100;
             end
            if newPopPos(i,j)>300
                newPopPos(i,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if newPopPos(i,j)<150
                newPopPos(i,j)=150;
             end
            if newPopPos(i,j)>500
                newPopPos(i,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if newPopPos(i,j)<40
                newPopPos(i,j)=40;
             end
            if newPopPos(i,j)>160
                newPopPos(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if newPopPos(i,j)<20
                newPopPos(i,j)=20;
             end
            if newPopPos(i,j)>130
                newPopPos(i,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if newPopPos(i,j)<25
                newPopPos(i,j)=25;
             end
            if newPopPos(i,j)>185
                newPopPos(i,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if newPopPos(i,j)<20
                newPopPos(i,j)=20;
             end
            if newPopPos(i,j)>80
                newPopPos(i,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if newPopPos(i,j)<30
                newPopPos(i,j)=30;
             end
            if newPopPos(i,j)>85
                newPopPos(i,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if newPopPos(i,j)<30
                newPopPos(i,j)=30;
             end
            if newPopPos(i,j)>120
                newPopPos(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if newPopPos(i,j)<40
                newPopPos(i,j)=40;
             end
            if newPopPos(i,j)>120
                newPopPos(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if newPopPos(i,j)<30
                newPopPos(i,j)=30;
             end
            if newPopPos(i,j)>100
                newPopPos(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end

               [newPopFit(i),MRFO_PL,MRFO_PTotal]=f20_ELD_mobjective(newPopPos(i,:));    
              if newPopFit(i)<PopFit(i)
                 PopFit(i)=newPopFit(i);
                 PopPos(i,:)=newPopPos(i,:);
              end
           end
     
            S=2;
        for i=1:N           
            newPopPos(i,:)=PopPos(i,:)+S*(rand*MRFOBestX-rand*PopPos(i,:)); %Equation (8)
        end
     
     for i=1:N        
         newPopPos(i,:)=SpaceBound(newPopPos(i,:),UB,LB);
         [newPopFit(i),PL,PTotal]=f20_ELD_mobjective(newPopPos(i,:));    
         if newPopFit(i)<PopFit(i)
            PopFit(i)=newPopFit(i);
            PopPos(i,:)=newPopPos(i,:);
         end
     end
     
     for i=1:N
        if PopFit(i)<MRFOBestF
           MRFOBestF=PopFit(i);
           MRFOBestX=PopPos(i,:);      
                   MRFO_PL=PL;
        MRFO_PTotal=PTotal;
        end
     end
 
  
     MRFOTCNVG6(It)=MRFOBestF;
end
