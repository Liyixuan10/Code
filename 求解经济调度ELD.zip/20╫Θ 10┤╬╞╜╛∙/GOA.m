function [GOATop_gazelle_fit,GOATop_gazelle_pos,GOAConvergence_curve,GOA_PL,GOA_PTotal]=GOA(Dim,N,M_Iter,LB,UB,f20_ELD_mobjective)
GOATop_gazelle_pos=zeros(1,Dim);
GOATop_gazelle_fit=inf; 
GOAConvergence_curve=zeros(1,M_Iter);
stepsize=zeros(N,Dim);
fitness=inf(N,1);
gazelle=initialization(N,Dim,UB,LB);
Xmin=repmat(ones(1,Dim).*LB,N,1);
Xmax=repmat(ones(1,Dim).*UB,N,1);
Iter=0;
PSRs=0.34;
S=0.88;
s=rand();
GOA_PL=0;
GOA_PTotal=0;
while Iter<M_Iter    
     %------------------- Evaluating top gazelle -----------------    
 for i=1:size(gazelle,1)  
        
    Flag4ub=gazelle(i,:)>UB;
    Flag4lb=gazelle(i,:)<LB;    
    gazelle(i,:)=(gazelle(i,:).*(~(Flag4ub+Flag4lb)))+UB.*Flag4ub+LB.*Flag4lb;                    
        
    fitness(i,1)=f20_ELD_mobjective(gazelle(i,:));
                     
     if fitness(i,1)<GOATop_gazelle_fit 
       GOATop_gazelle_fit=fitness(i,1); 
       GOATop_gazelle_pos=gazelle(i,:);
     end          
 end
     
     %------------------- Keeping tract of fitness values------------------- 
    
 if Iter==0
   fit_old=fitness;    Prey_old=gazelle;
 end
     
  Inx=(fit_old<fitness);
  Indx=repmat(Inx,1,Dim);
  gazelle=Indx.*Prey_old+~Indx.*gazelle;
  fitness=Inx.*fit_old+~Inx.*fitness;
        
  fit_old=fitness;    Prey_old=gazelle;

     %------------------------------------------------------------   
     
 Elite=repmat(GOATop_gazelle_pos,N,1);  %(Eq. 3) 
 CF=(1-Iter/M_Iter)^(2*Iter/M_Iter);
                             
 RL=0.05*levy(N,Dim,1.5);   %Levy random number vector
 RB=randn(N,Dim);          %Brownian random number vector
           
  for i=1:size(gazelle,1)
     for j=1:size(gazelle,2)        
       R=rand();
       r=rand();
       if mod(Iter,2)==0
             mu=-1;
       else
             mu=1;
       end
          %------------------ Exploitation ------------------- 
       if r>0.5 
          stepsize(i,j)=RB(i,j)*(Elite(i,j)-RB(i,j)*gazelle(i,j));                    
          gazelle(i,j)=gazelle(i,j)+s*R*stepsize(i,j); 
             
          %--------------- Exploration----------------
       else 
          
         if i>size(gazelle,1)/2
            stepsize(i,j)=RB(i,j)*(RL(i,j)*Elite(i,j)-gazelle(i,j));
            gazelle(i,j)=Elite(i,j)+S*mu*CF*stepsize(i,j); 
         else
            stepsize(i,j)=RL(i,j)*(Elite(i,j)-RL(i,j)*gazelle(i,j));                     
            gazelle(i,j)=gazelle(i,j)+S*mu*R*stepsize(i,j);  
         end  
         
          
       end  
      end                                         
  end    
        
     %------------------ Updating top gazelle ------------------        
  for i=1:size(gazelle,1)  
        
%     Flag4ub=gazelle(i,:)>UB;  
%     Flag4lb=gazelle(i,:)<LB;  
%     gazelle(i,:)=(gazelle(i,:).*(~(Flag4ub+Flag4lb)))+UB.*Flag4ub+LB.*Flag4lb;
        for j=1:1
            if gazelle(i,j)<150
                gazelle(i,j)=150;
            end
            if gazelle(i,j)>600
                gazelle(i,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if gazelle(i,j)<50
                gazelle(i,j)=50;
             end
            if gazelle(i,j)>200
                gazelle(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if gazelle(i,j)<50
                gazelle(i,j)=50;
             end
            if gazelle(i,j)>160
                gazelle(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if gazelle(i,j)<20
                gazelle(i,j)=20;
             end
            if gazelle(i,j)>100
                gazelle(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if gazelle(i,j)<25
                gazelle(i,j)=25;
             end
            if gazelle(i,j)>125
                gazelle(i,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if gazelle(i,j)<50
                gazelle(i,j)=50;
             end
            if gazelle(i,j)>150
                gazelle(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if gazelle(i,j)<50
                gazelle(i,j)=50;
             end
            if gazelle(i,j)>200
                gazelle(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if gazelle(i,j)<30
                gazelle(i,j)=30;
             end
            if gazelle(i,j)>150
                gazelle(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if gazelle(i,j)<100
                gazelle(i,j)=100;
             end
            if gazelle(i,j)>300
                gazelle(i,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if gazelle(i,j)<150
                gazelle(i,j)=150;
             end
            if gazelle(i,j)>500
                gazelle(i,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if gazelle(i,j)<40
                gazelle(i,j)=40;
             end
            if gazelle(i,j)>160
                gazelle(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if gazelle(i,j)<20
                gazelle(i,j)=20;
             end
            if gazelle(i,j)>130
                gazelle(i,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if gazelle(i,j)<25
                gazelle(i,j)=25;
             end
            if gazelle(i,j)>185
                gazelle(i,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if gazelle(i,j)<20
                gazelle(i,j)=20;
             end
            if gazelle(i,j)>80
                gazelle(i,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if gazelle(i,j)<30
                gazelle(i,j)=30;
             end
            if gazelle(i,j)>85
                gazelle(i,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if gazelle(i,j)<30
                gazelle(i,j)=30;
             end
            if gazelle(i,j)>120
                gazelle(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if gazelle(i,j)<40
                gazelle(i,j)=40;
             end
            if gazelle(i,j)>120
                gazelle(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
  end
                  for j=20:20
             if gazelle(i,j)<30
                gazelle(i,j)=30;
             end
            if gazelle(i,j)>100
                gazelle(i,j)=100;
            end
    [fitness(i,1),PL,PTotal]=f20_ELD_mobjective(gazelle(i,:));
        
      if fitness(i,1)<GOATop_gazelle_fit 
         GOATop_gazelle_fit=fitness(i,1);
         GOATop_gazelle_pos=gazelle(i,:);
                                             GOA_PL=PL;
    GOA_PTotal=PTotal;
      end     
  end
        
     %---------------------- Updating history of fitness values ----------------
    
 if Iter==0
    fit_old=fitness;    Prey_old=gazelle;
 end
     
    Inx=(fit_old<fitness);
    Indx=repmat(Inx,1,Dim);
    gazelle=Indx.*Prey_old+~Indx.*gazelle;
    fitness=Inx.*fit_old+~Inx.*fitness;
        
    fit_old=fitness;    Prey_old=gazelle;

     %---------- Applying PSRs ----------- 
                             
  if rand()<PSRs
     U=rand(N,Dim)<PSRs;                                                                                              
     gazelle=gazelle+CF*((Xmin+rand(N,Dim).*(Xmax-Xmin)).*U);

  else
     r=rand();  Rs=size(gazelle,1);
     stepsize=(PSRs*(1-r)+r)*(gazelle(randperm(Rs),:)-gazelle(randperm(Rs),:));
     gazelle=gazelle+stepsize;
  end
                                                        
  Iter=Iter+1;  
  GOAConvergence_curve(Iter)=GOATop_gazelle_fit; 
       
end

