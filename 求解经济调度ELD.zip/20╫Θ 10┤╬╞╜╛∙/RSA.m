%_______________________________________________________________________________________%
%  Reptile Search Algroithm (RSA) source codes demo version 1.0                         %
%                                                                                       %
%  Developed in MATLAB R2015a (7.13)                                                    %
%                                                                                       %
%  Author and programmer: Laith Abualigah                                               %
%                                                                                       %
%         e-Mail: Aligah.2020@gmail.com                                                 %
%       Homepage:                                                                       %
%         1- https://scholar.google.com/citations?user=39g8fyoAAAAJ&hl=en               %
%         2- https://www.researchgate.net/profile/Laith_Abualigah                       %
%_______________________________________________________________________________________%
%  Main paper:            Reptile Search Algorithm (RSA):                               %
%                  A novel nature-inspired metaheuristic algorithm                      %                                                                       %
%_______________________________________________________________________________________%
            
function [RSABest_F,RSABest_P,RSACNVG4,RSA_PL,RSA_PTotal]=RSA(N,M_Iter,LB,UB,Dim,f20_ELD_mobjective)
RSABest_P=zeros(1,Dim);           % best positions
RSABest_F=inf;                    % best fitness
X=initializationRSA(N,Dim,UB,LB); %Initialize the positions of solution
Xnew=zeros(N,Dim);
RSACNVG4=zeros(1,M_Iter);               % Convergance array
RSA_PL=0;
RSA_PTotal=0;

t=1;                         % starting iteration
Alpha=0.1;                   % the best value 0.1
Beta=0.005;                  % the best value 0.005
Ffun=zeros(1,size(X,1));     % (old fitness values)
Ffun_new=zeros(1,size(X,1)); % (new fitness values)

for i=1:size(X,1) 
    Ffun(1,i)=f20_ELD_mobjective(X(i,:));   %Calculate the fitness values of solutions
        if Ffun(1,i)<RSABest_F
            RSABest_F=Ffun(1,i);
            RSABest_P=X(i,:);
        end
end
  

while t<M_Iter+1  %Main loop %Update the Position of solutions
    ES=2*randn*(1-(t/M_Iter));  % Probability Ratio
    for i=2:size(X,1) 
        for j=1:size(X,2)  
                R=RSABest_P(1,j)-X(randi([1 size(X,1)]),j)/((RSABest_P(1,j))+eps);
                P=Alpha+(X(i,j)-mean(X(i,:)))/(RSABest_P(1,j)*(UB(j)-LB(j))+eps);
                Eta=RSABest_P(1,j)*P;
                if (t<M_Iter/4)
                    Xnew(i,j)=RSABest_P(1,j)-Eta*Beta-R*rand;    
                elseif (t<2*M_Iter/4 && t>=M_Iter/4)
                    Xnew(i,j)=RSABest_P(1,j)*X(randi([1 size(X,1)]),j)*ES*rand;
                elseif (t<3*M_Iter/4 && t>=2*M_Iter/4)
                    Xnew(i,j)=RSABest_P(1,j)*P*rand;
                else
                    Xnew(i,j)=RSABest_P(1,j)-Eta*eps-R*rand;
                end
        end
            
        for j=1:1
            if Xnew(i,j)<150
                Xnew(i,j)=150;
            end
            if Xnew(i,j)>600
                Xnew(i,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>200
                Xnew(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>160
                Xnew(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>100
                Xnew(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if Xnew(i,j)<25
                Xnew(i,j)=25;
             end
            if Xnew(i,j)>125
                Xnew(i,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>150
                Xnew(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>200
                Xnew(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>150
                Xnew(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if Xnew(i,j)<100
                Xnew(i,j)=100;
             end
            if Xnew(i,j)>300
                Xnew(i,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if Xnew(i,j)<150
                Xnew(i,j)=150;
             end
            if Xnew(i,j)>500
                Xnew(i,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if Xnew(i,j)<40
                Xnew(i,j)=40;
             end
            if Xnew(i,j)>160
                Xnew(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>130
                Xnew(i,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if Xnew(i,j)<25
                Xnew(i,j)=25;
             end
            if Xnew(i,j)>185
                Xnew(i,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>80
                Xnew(i,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>85
                Xnew(i,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>120
                Xnew(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if Xnew(i,j)<40
                Xnew(i,j)=40;
             end
            if Xnew(i,j)>120
                Xnew(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>100
                Xnew(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
            
           [Ffun_new(1,i),PL,PTotal]=f20_ELD_mobjective(Xnew(i,:));
            if Ffun_new(1,i)<Ffun(1,i)
                X(i,:)=Xnew(i,:);
                Ffun(1,i)=Ffun_new(1,i);
            end
            if Ffun(1,i)<RSABest_F
                RSABest_F=Ffun(1,i);
                RSABest_P=X(i,:);
                         RSA_PL=PL;
        RSA_PTotal=PTotal;
            end
    end
  
    RSACNVG4(t)=RSABest_F;  %Update the convergence curve

    if mod(t,50)==0  %Print the best universe details after every 50 iterations
        display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(RSABest_F)]);
    end
     t=t+1;
end
end