clear all 
clc
N=20; 
Dim=20;
M_Iter=1000; 
n1=[];
n2=[];
n3=[];
n4=[];
n5=[];
n6=[];
n7=[];
n8=[];
LB=[150,50,50,50,50,20,25,50,50,30,100,150,40,20,25,20, 30,30,40,30];
UB=[600,200,200,200,160,100,125,150,200,150,300,500,160,130,185,80,85,120,120,100];
for i=1:1
    
    [AOABest_FF,AOABest_P,AOAConv_curve,AOA_PL,AOA_PTotal]=AOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [TAOABest_FF,TAOABest_P,TAOA_Conv_curve,TAOA_PL,TAOA_PTotal]=TAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [PAOABest_FF,PAOABest_P,PAOA_Conv_curve,PAOA_PL,PAOA_PTotal]=PAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [LAOABest_FF,LAOABest_P,LAOA_Conv_curve,LAOA_PL,LAOA_PTotal]=LAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [GAOABest_FF,GAOABest_P,GAOA_Conv_curve,GAOA_PL,GAOA_PTotal]=GAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [SAOABest_FF,SAOABest_P,SAOA_Conv_curve,SAOA_PL,SAOA_PTotal]=SAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [CAOABest_FF,CAOABest_P,CAOA_Conv_curve,CAOA_PL,CAOA_PTotal]=CAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [SGAOABest_FF,SGAOABest_P,SGAOA_Conv_curve,SGAOA_PL,SGAOA_PTotal]=SGAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    
%  [AOA_Best_FF,AOA_Best_P,AOA_Conv_curve,AOA_PL,AOA_PTotal]=AOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
%  [sinAOA_Best_FF,sinAOA_Best_P,sinAOA_Conv_curve,sinAOA_PL,sinAOA_PTotal]=sinAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [tanAOA_Best_FF,tanAOA_Best_P,tanAOA_Conv_curve,tanAOA_PL,tanAOA_PTotal]=tanAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
%  [sechAOA_Best_FF,sechAOA_Best_P,sechAOA_Conv_curve,sechAOA_PL,sechAOA_PTotal]=sechAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [cschAOA_Best_FF,cschAOA_Best_P,cschAOA_Conv_curve,cschAOA_PL,cschAOA_PTotal]=cschAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [pAOA_Best_FF,pAOA_Best_P,pAOA_Conv_curve,pAOA_PL,pAOA_PTotal]=PAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [acosAOA_Best_FF,acosAOA_Best_P,acosAOA_Conv_curve,acosAOA_PL,acosAOA_PTotal]=acosAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
 
c1(i,:)=AOAConv_curve;
c2(i,:)=TAOA_Conv_curve;
c3(i,:)=PAOA_Conv_curve;
c4(i,:)=LAOA_Conv_curve;
c5(i,:)=GAOA_Conv_curve;
c6(i,:)=SAOA_Conv_curve;
c7(i,:)=CAOA_Conv_curve;
c8(i,:)=SGAOA_Conv_curve;

n1(end+1)=AOABest_FF;
n2(end+1)=TAOABest_FF;
n3(end+1)=PAOABest_FF;
n4(end+1)=LAOABest_FF;
n5(end+1)=GAOABest_FF;
n6(end+1)=SAOABest_FF;
n7(end+1)=CAOABest_FF;
n8(end+1)=SGAOABest_FF;

end
ave1=mean(n1);
ave2=mean(n2);
ave3=mean(n3);
ave4=mean(n4);
ave5=mean(n5);
ave6=mean(n6);
ave7=mean(n7);
ave8=mean(n8);

AOAConv_curve=mean(c1,1);
TAOA_Conv_curve=mean(c2,1);
PAOA_Conv_curve=mean(c3,1);
LAOA_Conv_curve=mean(c4,1);
GAOA_Conv_curve=mean(c5,1);
SAOA_Conv_curve=mean(c6,1);
CAOA_Conv_curve=mean(c7,1);
SGAOA_Conv_curve=mean(c8,1);
aave1=[ave1 ave2 ave3 ave4 ave5 ave6 ave7 ave8];

semilogy(AOAConv_curve,'DisplayName','AOA','color','r','Marker','+','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(TAOA_Conv_curve,'DisplayName','TAOA','color','g','Marker','o','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(PAOA_Conv_curve,'DisplayName','PAOA','color','b','Marker','*','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(LAOA_Conv_curve,'DisplayName','LAOA','Color','c','Marker','.','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(GAOA_Conv_curve,'DisplayName','GAOA','Color','m','Marker','x','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(SAOA_Conv_curve,'DisplayName','SAOA','Color','#D95319','Marker','s','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(CAOA_Conv_curve,'DisplayName','CAOA','Color','k','Marker','d','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(SGAOA_Conv_curve,'DisplayName','SGAOA','Color','#77AC30','Marker','diamond','markerindices',(1:100:1000),'LineWidth',1)
hold on
%  semilogy(tanAOA_Conv_curve,'DisplayName','tanAOA','color','b','Marker','s','markerindices',(1:200:1000),'MarkerSize',6)
% semilogy(BA_cg_curve,'DisplayName','BA','color','c','Marker','d','markerindices',(1:10:200),'MarkerSize',6)
% semilogy(HHO_cg_curve,'DisplayName','HHO','color','b','Marker','s','markerindices',(1:10:200),'MarkerSize',6)
axis tight
legend('AOA','TAOA','PAOA','LAOA','GAOA','SAOA','CAOA','SGAOA')%,'HGOA1','HGOA2','HGOA3','HGOA4','BA','HHO','GGOA','HGOA''GOA',


%%%%%%%%%��ʧ%%%%%%
%   fprintf('AOA_PL=%7.3f MW\n',AOA_PL);
%   fprintf('sinAOA_PL=%7.3f MW\n',sinAOA_PL);
%   fprintf('tanAOA_PL=%7.3f MW\n',tanAOA_PL);
%   fprintf('sechAOA_PL=%7.3f MW\n',sechAOA_PL);
%   fprintf('cschAOA_PL=%7.3f MW\n',cschAOA_PL);
%   fprintf('pAOA_PL=%7.3f MW\n',pAOA_PL);
%   fprintf('acosAOA_PL=%7.3f MW\n',acosAOA_PL);
%   fprintf('tanAOA_PL=%7.3f MW\n',tanAOA_PL);
%  fprintf('GGOA_PL=%7.3f MW\n',GGOA_PL);
%   fprintf('HGOA_PL=%7.3f MW\n',HGOA_PL);

% %%%%%�����%%%%%%%%%
%   fprintf('AOA_PTotal=%7.3f MW\n',AOA_PTotal);
%   fprintf('sinAOA_PTotal=%7.3f MW\n',sinAOA_PTotal);
%   fprintf('tanAOA_PTotal=%7.3f MW\n',tanAOA_PTotal);
%   fprintf('sechAOA_PTotal=%7.3f MW\n',sechAOA_PTotal);
%   fprintf('cschAOA_PTotal=%7.3f MW\n',cschAOA_PTotal);
%   fprintf('pAOA_PTotal=%7.3f MW\n',pAOA_PTotal);
%   fprintf('acosAOA_PTotal=%7.3f MW\n',acosAOA_PTotal);
% %   fprintf('tanAOA_PTotal=%7.3f MW\n',tanAOA_PTotal);
%  fprintf('GGOA_PTotal=%7.3f MW\n',GGOA_PTotal);
% fprintf('HGOA_PTotal=%7.3f MW\n',HGOA_PTotal);
%%%%%%������%%%%%
%   fprintf('AOA_Best_FF=%7.3f $\n',AOA_Best_FF);
%   fprintf('sinAOA_Best_FF=%7.3f $\n',sinAOA_Best_FF);
%   fprintf('tanAOA_Best_FF=%7.3f $\n',tanAOA_Best_FF);
%   fprintf('sechAOA_Best_FF=%7.3f $\n',sechAOA_Best_FF);
%   fprintf('cschAOA_Best_FF=%7.3f $\n',cschAOA_Best_FF);
%   fprintf('pAOA_Best_FF=%7.3f $\n',pAOA_Best_FF);
%   fprintf('acosAOA_Best_FF=%7.3f $\n',acosAOA_Best_FF);
%   fprintf('tanAOA_Best_FF=%7.3f $\n',tanAOA_Best_FF);
% % fprintf('GGOA_score=%7.3f $\n',GGOA_score);
%  fprintf('HGOA_score=%7.3f $\n',HGOA_score);
% m1=sum(AOA_Best_P);
% n1=(AOA_Best_P)*B*(AOA_Best_P)';
% m2=sum(sinAOA_Best_P);
% m3=sum(tanAOA_Best_P);
% m4=sum(sechAOA_Best_P);
% m5=sum(cschAOA_Best_P);
% m6=sum(pAOA_Best_P);
% m7=sum(acosAOA_Best_P);
