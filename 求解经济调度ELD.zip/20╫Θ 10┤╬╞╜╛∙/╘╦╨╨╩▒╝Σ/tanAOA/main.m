clear all 
clc
tic
N=20; 
Dim=20;
M_Iter=500; 
% n1=[];
% n2=[];
% n3=[];
% n4=[];
% n5=[];
% n6=[];
% n7=[];
LB=[150,50,50,50,50,20,25,50,50,30,100,150,40,20,25,20, 30,30,40,30];
UB=[600,200,200,200,160,100,125,150,200,150,300,500,160,130,185,80,85,120,120,100];
% for i=1:10
%  [AOA_Best_FF,AOA_Best_P,AOA_Conv_curve,AOA_PL,AOA_PTotal]=AOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
%  [sinAOA_Best_FF,sinAOA_Best_P,sinAOA_Conv_curve,sinAOA_PL,sinAOA_PTotal]=sinAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
 [tanAOA_Best_FF,tanAOA_Best_P,tanAOA_Conv_curve,tanAOA_PL,tanAOA_PTotal]=tanAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
%  [sechAOA_Best_FF,sechAOA_Best_P,sechAOA_Conv_curve,sechAOA_PL,sechAOA_PTotal]=sechAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [cschAOA_Best_FF,cschAOA_Best_P,cschAOA_Conv_curve,cschAOA_PL,cschAOA_PTotal]=cschAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [pAOA_Best_FF,pAOA_Best_P,pAOA_Conv_curve,pAOA_PL,pAOA_PTotal]=pAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [acosAOA_Best_FF,acosAOA_Best_P,acosAOA_Conv_curve,acosAOA_PL,acosAOA_PTotal]=acosAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
 %[GGOA_score,GGOA_cg_curve,GGOA_TargetPosition,GGOA_PL,GGOA_PTotal]=GGOA(dim,N,Max_iteration,lu,l,u,@f6_cubic_ELD_mobjective); 
% [HGOA_score,HGOA_cg_curve,HGOA_TargetPosition,HGOA_PL,HGOA_PTotal]=HGOA(dim,N,Max_iteration,lu,l,u,@f6_cubic_ELD_mobjective); 
% [BA_score,BA_cg_curve,BA_TargetPosition]=BA(dim,N,Max_iteration,lu,l,u,@f6_cubic_ELD_mobjective); 
% [HHO_score,HHO_cg_curve,HHO_TargetPosition]=HHO(dim,N,Max_iteration,lu,l,u,@f6_cubic_ELD_mobjective); 
% [HGOA3_score,HGOA3_cg_curve,HGOA3_TargetPosition]=HGOA3(dim,N,Max_iteration,lu,l,u,@f6_cubic_ELD_mobjective3); 
% [HGOA4_score,HGOA4_cg_curve,HGOA4_TargetPosition]=HGOA4(dim,N,Max_iteration,lu,l,u,@f6_cubic_ELD_mobjective4); 
%   semilogy(GOA_cg_curve,'DisplayName','GOA','color','b')%,'Marker','*','markerindices',(1:10:200),'MarkerSize',6
% % % semilogy(HGOA_cg_curve,'DisplayName','HGOA','color','k')%,'Marker','*','markerindices',(1:10:200),'MarkerSize',6
%  hold on
%  rsemilogy(GGOA_cg_curve,'DisplayName','GGOA','color','m','Marker','o','markerindices',(1:10:200),'MarkerSize',6)
% c1(i,:)=AOA_Conv_curve;
% c2(i,:)=sinAOA_Conv_curve;
% c3(i,:)=tanAOA_Conv_curve;
% c4(i,:)=sechAOA_Conv_curve;
% c5(i,:)=pAOA_Conv_curve;
% c6(i,:)=cschAOA_Conv_curve;
% c7(i,:)=acosAOA_Conv_curve;
% 
% n1(end+1)=AOA_Best_FF;
% n2(end+1)=sinAOA_Best_FF;
% n3(end+1)=tanAOA_Best_FF;
% n4(end+1)=sechAOA_Best_FF;
% n5(end+1)=pAOA_Best_FF;
% n6(end+1)=cschAOA_Best_FF;
% n7(end+1)=acosAOA_Best_FF;
% 
% end
% ave1=mean(n1);
% ave2=mean(n2);
% ave3=mean(n3);
% ave4=mean(n4);
% ave5=mean(n5);
% ave6=mean(n6);
% ave7=mean(n7);
% 
% AOA_Conv_curve=mean(c1,1);
% sinAOA_Conv_curve=mean(c2,1);
% tanAOA_Conv_curve=mean(c3,1);
% sechAOA_Conv_curve=mean(c4,1);
% pAOA_Conv_curve=mean(c5,1);
% cschAOA_Conv_curve=mean(c6,1);
% acosAOA_Conv_curve=mean(c7,1);
% aave1=[ave1 ave2 ave3 ave4 ave5 ave6 ave7];
% 
% semilogy(AOA_Conv_curve,'DisplayName','AOA','color','r','Marker','+','markerindices',(1:50:500),'MarkerSize',6)
% hold on
% semilogy(sinAOA_Conv_curve,'DisplayName','sinAOA','color','g','Marker','o','markerindices',(1:50:500),'MarkerSize',6)
% hold on
% semilogy(tanAOA_Conv_curve,'DisplayName','tanAOA','color','b','Marker','*','markerindices',(1:50:500),'MarkerSize',6)
% hold on
% semilogy(sechAOA_Conv_curve,'DisplayName','sechAOA','Color','c','Marker','.','markerindices',(1:50:500),'MarkerSize',6)
% hold on
% semilogy(pAOA_Conv_curve,'DisplayName','pAOA','Color','m','Marker','x','markerindices',(1:50:500),'MarkerSize',6)
% hold on
% semilogy(cschAOA_Conv_curve,'DisplayName','cschAOA','Color','y','Marker','s','markerindices',(1:50:500),'MarkerSize',6)
% hold on
% semilogy(acosAOA_Conv_curve,'DisplayName','acosAOA','Color','k','Marker','d','markerindices',(1:50:500),'MarkerSize',6)
% % hold on
% %  semilogy(tanAOA_Conv_curve,'DisplayName','tanAOA','color','b','Marker','s','markerindices',(1:200:1000),'MarkerSize',6)
% % semilogy(BA_cg_curve,'DisplayName','BA','color','c','Marker','d','markerindices',(1:10:200),'MarkerSize',6)
% % semilogy(HHO_cg_curve,'DisplayName','HHO','color','b','Marker','s','markerindices',(1:10:200),'MarkerSize',6)
% axis tight
% legend('AOA','sinAOA','tanAOA','sechAOA','pAOA','cschAOA','acosAOA')%,'HGOA1','HGOA2','HGOA3','HGOA4','BA','HHO','GGOA','HGOA''GOA',
%%%%%%%%%��ʧ%%%%%%
%   fprintf('AOA_PL=%7.3f MW\n',AOA_PL);
%   fprintf('sinAOA_PL=%7.3f MW\n',sinAOA_PL);
%   fprintf('tanAOA_PL=%7.3f MW\n',tanAOA_PL);
%   fprintf('sechAOA_PL=%7.3f MW\n',sechAOA_PL);
%   fprintf('cschAOA_PL=%7.3f MW\n',cschAOA_PL);
%   fprintf('pAOA_PL=%7.3f MW\n',pAOA_PL);
%   fprintf('acosAOA_PL=%7.3f MW\n',acosAOA_PL);
%   fprintf('tanAOA_PL=%7.3f MW\n',tanAOA_PL);
%  fprintf('GGOA_PL=%7.3f MW\n',GGOA_PL);
%   fprintf('HGOA_PL=%7.3f MW\n',HGOA_PL);

% %%%%%�����%%%%%%%%%
%   fprintf('AOA_PTotal=%7.3f MW\n',AOA_PTotal);
%   fprintf('sinAOA_PTotal=%7.3f MW\n',sinAOA_PTotal);
%   fprintf('tanAOA_PTotal=%7.3f MW\n',tanAOA_PTotal);
%   fprintf('sechAOA_PTotal=%7.3f MW\n',sechAOA_PTotal);
%   fprintf('cschAOA_PTotal=%7.3f MW\n',cschAOA_PTotal);
%   fprintf('pAOA_PTotal=%7.3f MW\n',pAOA_PTotal);
%   fprintf('acosAOA_PTotal=%7.3f MW\n',acosAOA_PTotal);
% %   fprintf('tanAOA_PTotal=%7.3f MW\n',tanAOA_PTotal);
%  fprintf('GGOA_PTotal=%7.3f MW\n',GGOA_PTotal);
% fprintf('HGOA_PTotal=%7.3f MW\n',HGOA_PTotal);
%%%%%%������%%%%%
%   fprintf('AOA_Best_FF=%7.3f $\n',AOA_Best_FF);
%   fprintf('sinAOA_Best_FF=%7.3f $\n',sinAOA_Best_FF);
%   fprintf('tanAOA_Best_FF=%7.3f $\n',tanAOA_Best_FF);
%   fprintf('sechAOA_Best_FF=%7.3f $\n',sechAOA_Best_FF);
%   fprintf('cschAOA_Best_FF=%7.3f $\n',cschAOA_Best_FF);
%   fprintf('pAOA_Best_FF=%7.3f $\n',pAOA_Best_FF);
%   fprintf('acosAOA_Best_FF=%7.3f $\n',acosAOA_Best_FF);
%   fprintf('tanAOA_Best_FF=%7.3f $\n',tanAOA_Best_FF);
% % fprintf('GGOA_score=%7.3f $\n',GGOA_score);
%  fprintf('HGOA_score=%7.3f $\n',HGOA_score);
% m1=sum(AOA_Best_P);
% n1=(AOA_Best_P)*B*(AOA_Best_P)';
% m2=sum(sinAOA_Best_P);
% m3=sum(tanAOA_Best_P);
% m4=sum(sechAOA_Best_P);
% m5=sum(cschAOA_Best_P);
% m6=sum(pAOA_Best_P);
% m7=sum(acosAOA_Best_P);
toc