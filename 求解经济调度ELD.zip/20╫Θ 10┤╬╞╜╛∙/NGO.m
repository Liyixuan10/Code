function [NGOScore,NGOBest_pos,NGO_curve,NGO_PL,NGO_PTotal]=NGO(Dim,N,M_Iter,LB,UB,f20_ELD_mobjective)
LB=ones(1,Dim).*(LB);   
% Lower limit for variables
UB=ones(1,Dim).*(UB);                              % Upper limit for variables
X=[];
X_new=[];
fit=[];
fit_new=[];
NGO_curve=zeros(1,M_Iter);
NGO_PL=0;
NGO_PTotal=0;
for i=1:Dim
    X(:,i) = LB(i)+rand(N,1).*(UB(i) -LB(i));              % Initial population
end
for i =1:N
    X_new=X(i,:);
    fit(i)=f20_ELD_mobjective(X_new);                    % Fitness evaluation (Explained at the top of the page. )
end
for t=1:M_Iter  % algorithm iteration   
    %%  update: BEST proposed solution
    [best , blocation]=min(fit);
    if t==1
        xbest=X(blocation,:);                                           % Optimal location
        fbest=best;                                           % The optimization objective function
    elseif best<fbest
        fbest=best;
        xbest=X(blocation,:);
    end
    %% UPDATE Northern goshawks based on PHASE1 and PHASE2
    for i=1:N
        %% Phase 1: Exploration
        I=round(1+rand);
        k=randperm(N,1);
        P=X(k,:); % Eq. (3)
        F_P=fit(k);
        if fit(i)> F_P
            X_new(i,:)=X(i,:)+rand(1,Dim) .* (P-I.*X(i,:)); % Eq. (4)
        else
            X_new(i,:)=X(i,:)+rand(1,Dim) .* (X(i,:)-P); % Eq. (4)
        end
        X_new(i,:) = max(X_new(i,:),LB);X_new(i,:) = min(X_new(i,:),UB);
        % update position based on Eq (5)
        X_new=X_new(i,:);
        [fit_new(i),PL,PTotal]=f20_ELD_mobjective(X_new);
        if(fit_new(i)<fit(i))
            NGOBest_pos = X_new(i,:);
            fit(i) = fit_new(i);
           NGO_PL=PL;
       NGO_PTotal=PTotal;
        end
        %% END PHASE 1
        %% PHASE 2 Exploitation
        R=0.02*(1-t/M_Iter);% Eq.(6)
        X_new(i,:)= X(i,:)+ (-R+2*R*rand(1,Dim)).*X(i,:);% Eq.(7)
        
        X_new(i,:) = max(X_new(i,:),LB);
        X_new(i,:) = min(X_new(i,:),UB);
          for j=1:1
            if X_new(i,j)<150
                X_new(i,j)=150;
            end
            if X_new(i,j)>600
                X_new(i,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if X_new(i,j)<50
                X_new(i,j)=50;
             end
            if X_new(i,j)>200
                X_new(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if X_new(i,j)<50
                X_new(i,j)=50;
             end
            if X_new(i,j)>160
                X_new(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if X_new(i,j)<20
                X_new(i,j)=20;
             end
            if X_new(i,j)>100
                X_new(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if X_new(i,j)<25
                X_new(i,j)=25;
             end
            if X_new(i,j)>125
                X_new(i,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if X_new(i,j)<50
                X_new(i,j)=50;
             end
            if X_new(i,j)>150
                X_new(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if X_new(i,j)<50
                X_new(i,j)=50;
             end
            if X_new(i,j)>200
                X_new(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if X_new(i,j)<30
                X_new(i,j)=30;
             end
            if X_new(i,j)>150
                X_new(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if X_new(i,j)<100
                X_new(i,j)=100;
             end
            if X_new(i,j)>300
                X_new(i,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if X_new(i,j)<150
                X_new(i,j)=150;
             end
            if X_new(i,j)>500
                X_new(i,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if X_new(i,j)<40
                X_new(i,j)=40;
             end
            if X_new(i,j)>160
                X_new(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if X_new(i,j)<20
                X_new(i,j)=20;
             end
            if X_new(i,j)>130
                X_new(i,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if X_new(i,j)<25
                X_new(i,j)=25;
             end
            if X_new(i,j)>185
                X_new(i,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if X_new(i,j)<20
                X_new(i,j)=20;
             end
            if X_new(i,j)>80
                X_new(i,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if X_new(i,j)<30
                X_new(ii,j)=30;
             end
            if X_new(i,j)>85
                X_new(i,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if X_new(i,j)<30
                X_new(i,j)=30;
             end
            if X_new(i,j)>120
                X_new(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if X_new(i,j)<40
                X_new(i,j)=40;
             end
            if X_new(i,j)>120
                X_new(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if X_new(i,j)<30
                X_new(i,j)=30;
             end
            if X_new(i,j)>100
                X_new(i,j)=100;
            end
        % update position based on Eq (8)
        X_new=X_new(i,:);
       [fit_new(i),PL,PTotal]=f20_ELD_mobjective(X_new);
        if(fit_new(i)<fit(i))
            X(i,:) = X_new(i,:);
           NGOBest_pos = fit_new(i);                                  
           NGO_PL=PL;
       NGO_PTotal=PTotal;
        end
        %% END PHASE 2
    end% end for i=1:N
    %%
    %% SAVE BEST SCORE
    best_so_far(t)=fbest; % save best solution so far
    average(t) = mean (fit);
    NGOScore=fbest;
    NGOBest_pos=xbest;
    NGO_curve(t)=NGOScore;
end
end


