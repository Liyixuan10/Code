function H=geteqH(g)
if g==0
    H=0;
else
    H=1; 
end