clear all 
clc
N=20; 
Dim=20;
M_Iter=1000; 
n1=[];
n2=[];
n3=[];
n4=[];
n5=[];
n6=[];
n7=[];

LB=[150,50,50,50,50,20,25,50,50,30,100,150,40,20,25,20, 30,30,40,30];
UB=[600,200,200,200,160,100,125,150,200,150,300,500,160,130,185,80,85,120,120,100];
for i=1:30
    
    [AOABest_FF,AOABest_P,AOAConv_curve,AOA_PL,AOA_PTotal]=AOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [LSCAOABest_FF,LSCAOABest_P,LSCAOA_Conv_curve,LSCAOA_PL,LSCAOA_PTotal]=LSCAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [STCAOABest_FF,STCAOABest_P,STCAOA_Conv_curve,STCAOA_PL,STCAOA_PTotal]=STCAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [TLCAOABest_FF,TLCAOABest_P,TLCAOA_Conv_curve,TLCAOA_PL,TLCAOA_PTotal]=TLCAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [SGCAOABest_FF,SGCAOABest_P,SGCAOA_Conv_curve,SGCAOA_PL,SGCAOA_PTotal]=SGCAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [LGCAOABest_FF,LGCAOABest_P,LGCAOA_Conv_curve,LGCAOA_PL,LGCAOA_PTotal]=LGCAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    [SSCAOABest_FF,SSCAOABest_P,SSCAOA_Conv_curve,SSCAOA_PL,SSCAOA_PTotal]=SSCAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
 
    
%  [AOA_Best_FF,AOA_Best_P,AOA_Conv_curve,AOA_PL,AOA_PTotal]=AOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
%  [sinAOA_Best_FF,sinAOA_Best_P,sinAOA_Conv_curve,sinAOA_PL,sinAOA_PTotal]=sinAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [tanAOA_Best_FF,tanAOA_Best_P,tanAOA_Conv_curve,tanAOA_PL,tanAOA_PTotal]=tanAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
%  [sechAOA_Best_FF,sechAOA_Best_P,sechAOA_Conv_curve,sechAOA_PL,sechAOA_PTotal]=sechAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [cschAOA_Best_FF,cschAOA_Best_P,cschAOA_Conv_curve,cschAOA_PL,cschAOA_PTotal]=cschAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [pAOA_Best_FF,pAOA_Best_P,pAOA_Conv_curve,pAOA_PL,pAOA_PTotal]=PAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective);
%  [acosAOA_Best_FF,acosAOA_Best_P,acosAOA_Conv_curve,acosAOA_PL,acosAOA_PTotal]=acosAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective); 
 
c1(i,:)=AOAConv_curve;
c2(i,:)=LSCAOA_Conv_curve;
c3(i,:)=STCAOA_Conv_curve;
c4(i,:)=TLCAOA_Conv_curve;
c5(i,:)=SGCAOA_Conv_curve;
c6(i,:)=LGCAOA_Conv_curve;
c7(i,:)=SSCAOA_Conv_curve;


n1(end+1)=AOABest_FF;
n2(end+1)=LSCAOABest_FF;
n3(end+1)=STCAOABest_FF;
n4(end+1)=TLCAOABest_FF;
n5(end+1)=SGCAOABest_FF;
n6(end+1)=LGCAOABest_FF;
n7(end+1)=SSCAOABest_FF;


end
ave1=mean(n1);
ave2=mean(n2);
ave3=mean(n3);
ave4=mean(n4);
ave5=mean(n5);
ave6=mean(n6);
ave7=mean(n7);


AOAConv_curve=mean(c1,1);
LSCAOA_Conv_curve=mean(c2,1);
STCAOA_Conv_curve=mean(c3,1);
TLCAOA_Conv_curve=mean(c4,1);
SGCAOA_Conv_curve=mean(c5,1);
LGCAOA_Conv_curve=mean(c6,1);
SSCAOA_Conv_curve=mean(c7,1);

aave1=[ave1 ave2 ave3 ave4 ave5 ave6 ave7];

semilogy(AOAConv_curve,'DisplayName','AOA','color','r','Marker','+','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(LSCAOA_Conv_curve,'DisplayName','TAOA','color','g','Marker','o','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(STCAOA_Conv_curve,'DisplayName','PAOA','color','b','Marker','*','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(TLCAOA_Conv_curve,'DisplayName','LAOA','Color','c','Marker','.','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(SGCAOA_Conv_curve,'DisplayName','GAOA','Color','m','Marker','x','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(LGCAOA_Conv_curve,'DisplayName','SAOA','Color','#D95319','Marker','s','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(SSCAOA_Conv_curve,'DisplayName','CAOA','Color','k','Marker','d','markerindices',(1:100:1000),'LineWidth',1)
hold on
%  semilogy(tanAOA_Conv_curve,'DisplayName','tanAOA','color','b','Marker','s','markerindices',(1:200:1000),'MarkerSize',6)
% semilogy(BA_cg_curve,'DisplayName','BA','color','c','Marker','d','markerindices',(1:10:200),'MarkerSize',6)
% semilogy(HHO_cg_curve,'DisplayName','HHO','color','b','Marker','s','markerindices',(1:10:200),'MarkerSize',6)
axis tight
legend('AOA','LSCAOA','STCAOA','TLCAOA','SGCAOA','LGCAOA','SSCAOA')%,'HGOA1','HGOA2','HGOA3','HGOA4','BA','HHO','GGOA','HGOA''GOA',


%%%%%%%%%��ʧ%%%%%%
%   fprintf('AOA_PL=%7.3f MW\n',AOA_PL);
%   fprintf('sinAOA_PL=%7.3f MW\n',sinAOA_PL);
%   fprintf('tanAOA_PL=%7.3f MW\n',tanAOA_PL);
%   fprintf('sechAOA_PL=%7.3f MW\n',sechAOA_PL);
%   fprintf('cschAOA_PL=%7.3f MW\n',cschAOA_PL);
%   fprintf('pAOA_PL=%7.3f MW\n',pAOA_PL);
%   fprintf('acosAOA_PL=%7.3f MW\n',acosAOA_PL);
%   fprintf('tanAOA_PL=%7.3f MW\n',tanAOA_PL);
%  fprintf('GGOA_PL=%7.3f MW\n',GGOA_PL);
%   fprintf('HGOA_PL=%7.3f MW\n',HGOA_PL);

% %%%%%�����%%%%%%%%%
%   fprintf('AOA_PTotal=%7.3f MW\n',AOA_PTotal);
%   fprintf('sinAOA_PTotal=%7.3f MW\n',sinAOA_PTotal);
%   fprintf('tanAOA_PTotal=%7.3f MW\n',tanAOA_PTotal);
%   fprintf('sechAOA_PTotal=%7.3f MW\n',sechAOA_PTotal);
%   fprintf('cschAOA_PTotal=%7.3f MW\n',cschAOA_PTotal);
%   fprintf('pAOA_PTotal=%7.3f MW\n',pAOA_PTotal);
%   fprintf('acosAOA_PTotal=%7.3f MW\n',acosAOA_PTotal);
% %   fprintf('tanAOA_PTotal=%7.3f MW\n',tanAOA_PTotal);
%  fprintf('GGOA_PTotal=%7.3f MW\n',GGOA_PTotal);
% fprintf('HGOA_PTotal=%7.3f MW\n',HGOA_PTotal);
%%%%%%������%%%%%
%   fprintf('AOA_Best_FF=%7.3f $\n',AOA_Best_FF);
%   fprintf('sinAOA_Best_FF=%7.3f $\n',sinAOA_Best_FF);
%   fprintf('tanAOA_Best_FF=%7.3f $\n',tanAOA_Best_FF);
%   fprintf('sechAOA_Best_FF=%7.3f $\n',sechAOA_Best_FF);
%   fprintf('cschAOA_Best_FF=%7.3f $\n',cschAOA_Best_FF);
%   fprintf('pAOA_Best_FF=%7.3f $\n',pAOA_Best_FF);
%   fprintf('acosAOA_Best_FF=%7.3f $\n',acosAOA_Best_FF);
%   fprintf('tanAOA_Best_FF=%7.3f $\n',tanAOA_Best_FF);
% % fprintf('GGOA_score=%7.3f $\n',GGOA_score);
%  fprintf('HGOA_score=%7.3f $\n',HGOA_score);
% m1=sum(AOA_Best_P);
% n1=(AOA_Best_P)*B*(AOA_Best_P)';
% m2=sum(sinAOA_Best_P);
% m3=sum(tanAOA_Best_P);
% m4=sum(sechAOA_Best_P);
% m5=sum(cschAOA_Best_P);
% m6=sum(pAOA_Best_P);
% m7=sum(acosAOA_Best_P);