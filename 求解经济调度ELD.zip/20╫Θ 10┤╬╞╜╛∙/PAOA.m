
function [PAOABest_FF,PAOABest_P,PAOA_Conv_curve,PAOA_PL,PAOA_PTotal]=PAOA(Dim,N,M_Iter,LB,UB,f20_ELD_mobjective)
display('tanAOA Working');
%Two variables to keep the positions and the fitness value of the best-obtained solution

PAOABest_P=zeros(1,Dim);
PAOABest_FF=inf;
PAOA_Conv_curve=zeros(1,M_Iter);
PAOA_PL=0;
PAOA_PTotal=0;
%Initialize the positions of solution
X=initialization(N,Dim,UB,LB);
Xnew=X;
Ffun=zeros(1,size(X,1));% (fitness values)
Ffun_new=zeros(1,size(Xnew,1));% (fitness values)

% MOA_Max=1;
% MOA_Min=0.2;
% C_Iter=1;
% Alpha=5;
% Mu=0.499;
MOP_Max=1;
MOP_Min=0.2;
C_Iter=1;
Alpha=5;
Mu=0.499;
a=0.5;
x(1)=rand;
y(1)=rand;
P=0.4;

for i=1:size(X,1)
    Ffun(1,i)=f20_ELD_mobjective(X(i,:));  %Calculate the fitness values of solutions
    if Ffun(1,i)<PAOABest_FF
        PAOABest_FF=Ffun(1,i);
        PAOABest_P=X(i,:);
    end
end

    
    

while C_Iter<M_Iter+1  %Main loop
   t = C_Iter;
    T = M_Iter;
        if x(t)>=0 && x(t)<P
        x(t+1)=sin(pi*(a*x(t)/P)+(1-a)*sin(pi*y(t)));
    end
    if x(t)>=P && x(t)<0.5
        x(t+1)=sin(pi*(a*(x(t)-P)/(0.5-P))+(1-a)*sin(pi*y(t)));
    end
    
    if x(t)>=0.5 && x(t)<1-P
        x(t+1)=sin(pi*(a*(1-P-x(t))/(0.5-P))+(1-a)*sin(pi*y(t)));
    end
    if x(t)>=1-P && x(t)<1
        x(t+1)=sin(pi*(a*(1-x(t))/P)+(1-a)*sin(pi*y(t)));
    end
    
    if y(t)>=0 && y(t)<P
        y(t+1)=sin(pi*(a*y(t)/P)+(1-a)*sin(pi*x(t).^2));
    end
     if y(t)>=P && y(t)<0.5
        y(t+1)=sin(pi*(a*(y(t)-P)/(0.5-P))+(1-a)*sin(pi*x(t).^2));
     end
     if y(t)>=0.5 && y(t)<1-P
        y(t+1)=sin(pi*(a*(1-P-y(t))/(0.5-P))+(1-a)*sin(pi*x(t).^2));
     end
    if y(t)>=1-P && y(t)<1
        y(t+1)=sin(pi*(a*(1-y(t))/P)+(1-a)*sin(pi*x(t).^2));
    end
     p=sqrt(x.^2+y.^2)
     v=atan2(y,x);
    
     MOP=(1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha)))*p(t+1)*0.75;
    
     MOA=(MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter))^(2)*v(t+1)*0.8; 
   
    %Update the Position of solutions
    for i=1:size(X,1)   % if each of the UB and LB has a just value 
        for j=1:size(X,2)
           r1=rand();
            if (size(LB,2)==1)
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=PAOABest_P(1,j)/(MOP+eps)*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j)=PAOABest_P(1,j)*MOP*((UB-LB)*Mu+LB);
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=PAOABest_P(1,j)-MOP*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j)=PAOABest_P(1,j)+MOP*((UB-LB)*Mu+LB);
                    end
                end               
            end
            
           
            if (size(LB,2)~=1)   % if each of the UB and LB has more than one value 
                r1=rand();
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=PAOABest_P(1,j)/(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j)=PAOABest_P(1,j)*MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=PAOABest_P(1,j)-MOP*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j)=PAOABest_P(1,j)+MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                end               
            end
            
        end
        
        for j=1:1
            if Xnew(i,j)<150
                Xnew(i,j)=150;
            end
            if Xnew(i,j)>600
                Xnew(i,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>200
                Xnew(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>160
                Xnew(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>100
                Xnew(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if Xnew(i,j)<25
                Xnew(i,j)=25;
             end
            if Xnew(i,j)>125
                Xnew(i,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>150
                Xnew(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>200
                Xnew(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>150
                Xnew(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if Xnew(i,j)<100
                Xnew(i,j)=100;
             end
            if Xnew(i,j)>300
                Xnew(i,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if Xnew(i,j)<150
                Xnew(i,j)=150;
             end
            if Xnew(i,j)>500
                Xnew(i,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if Xnew(i,j)<40
                Xnew(i,j)=40;
             end
            if Xnew(i,j)>160
                Xnew(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>130
                Xnew(i,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if Xnew(i,j)<25
                Xnew(i,j)=25;
             end
            if Xnew(i,j)>185
                Xnew(i,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>80
                Xnew(i,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>85
                Xnew(i,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>120
                Xnew(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if Xnew(i,j)<40
                Xnew(i,j)=40;
             end
            if Xnew(i,j)>120
                Xnew(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>100
                Xnew(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
 
        [Ffun_new(1,i),PL,PTotal]=f20_ELD_mobjective(Xnew(i,:));  % calculate Fitness function 
        if Ffun_new(1,i)<Ffun(1,i)
            X(i,:)=Xnew(i,:);
            Ffun(1,i)=Ffun_new(1,i);
        end
        if Ffun(1,i)<PAOABest_FF
        PAOABest_FF=Ffun(1,i);
        PAOABest_P=X(i,:);
        PAOA_PL=PL;
        PAOA_PTotal=PTotal;
        end
    end
       

    

    %Update the convergence curve
    PAOA_Conv_curve(C_Iter)=PAOABest_FF;
    
    %Print the best solution details after every 50 iterations
    if mod(C_Iter,50)==0
        display(['At iteration ', num2str(C_Iter), ' the best solution fitness is ', num2str(PAOABest_FF)]);
    end
     
    C_Iter=C_Iter+1;  % incremental iteration
end
end
   





