%_________________________________________________________________________%
%  Dingo Optimization Algorithm (DOA) source code                         %
%                                                                         %
%  Developed in MATLAB 9.4.0.813654 (R2018a)                              %
%                                                                         %
%  Author: Dr. Hernan Peraza-Vazquez                                      %
%          MTA. Gustavo Echavarria-Castillo                               %
%                                                                         %
%  e-mail:  hperaza@ipn.mx        gechavarriac1700@alumno.ipn.mx          %
%                                                                         %
%  Programmer:  Dr. Hernan Peraza-Vazquez                                 %
%  Main paper:                                                            %
%  A Bio-Inspired Method for Engineering Design Optimization Inspired by  %
%  Dingoes Hunting Strategies.                                            %
%  Mathematical Problems in Engineering. (2021). Hindawi.                 %                                                      %
%  DOI:   doi.org/10.1155/2021/9107547                                    %
%_________________________________________________________________________%
function [DOA_vMin,DOA_theBestVct,DOA_Convergence_curve,DOA_PL,DOA_PTotal]=DOA(N,M_Iter,LB,UB,Dim,f20_ELD_mobjective)
P= 0.5;  % Hunting or Scavenger?  rate.  See section 3.0.4, P and Q parameters analysis
Q= 0.7;  % Group attack or persecution? 
beta1= -2 + 4* rand();  % -2 < beta < 2     Used in Eq. 2, 
beta2= -1 + 2* rand();  % -1 < beta2 < 1    Used in Eq. 2,3, and 4
naIni= 2; % minimum number of dingoes that will attack
naEnd= N /naIni; % maximum number of dingoes that will attack
na= round(naIni + (naEnd-naIni) * rand());
DOA_PL=0;
DOA_PTotal=0;% number of dingoes that will attack, used in Attack.m Section 2.2.1: Group attack
Positions=initializationDOA(N,Dim,UB,LB);
 for i=1:size(Positions,1)
      Fitness(i)=f20_ELD_mobjective(Positions(i,:)); % get fitness     
 end
[DOA_vMin minIdx]= min(Fitness);  % the min fitness value vMin and the position minIdx
DOA_theBestVct= Positions(minIdx,:);  % the best vector
[vMax maxIdx]= max(Fitness); % the max fitness value vMax and the position maxIdx
DOA_Convergence_curve=zeros(1,M_Iter);
DOA_Convergence_curve(1)= DOA_vMin;
survival= survival_rate(Fitness,DOA_vMin,vMax);  % Section 2.2.4 Dingoes'survival rates
t=0;% Loop counter
% Main loop
for t=1:M_Iter       
   for r=1:N
      sumatory=0;
    if rand() < P  % If Hunting?
           sumatory= Attack( N, na, Positions, r );     % Section 2.2.1, Strategy 1: Part of Eq.2   
           if rand() < Q  % If group attack?                
                 v(r,:)=  beta1 * sumatory-DOA_theBestVct; % Strategy 1: Eq.2
           else  %  Persecution
               r1= round(1+ (N-1)* rand()); % 
               v(r,:)= DOA_theBestVct + beta1*(exp(beta2))*((Positions(r1,:)-Positions(r,:))); % Section 2.2.2, Strategy 2:  Eq.3
           end  
    else % Scavenger
        r1= round(1+ (N-1)* rand());
        v(r,:)=   (exp(beta2)* Positions(r1,:)-((-1)^getBinary)*Positions(r,:))/2; % Section 2.2.3, Strategy 3: Eq.4
    end
    if survival(r) <= 0.3  % Section 2.2.4, Algorithm 3 - Survival procedure
         band=1; 
         while band 
           r1= round(1+ (N-1)* rand());
           r2= round(1+ (N-1)* rand());
           if r1 ~= r2 
               band=0;
           end
         end
              v(r,:)=   DOA_theBestVct + (Positions(r1,:)-((-1)^getBinary)*Positions(r2,:))/2;  % Section 2.2.4, Strategy 4: Eq.6
    end 
     % Return back the search agents that go beyond the boundaries of the search space .  
%         Flag4ub=v(r,:)>UB;
%         Flag4lb=v(r,:)<LB;
%         v(r,:)=(v(r,:).*(~(Flag4ub+Flag4lb)))+UB.*Flag4ub+LB.*Flag4lb;
    % Evaluate new solutions
     for j=1:1
            if v(r,j)<150
                v(r,j)=150;
            end
            if v(r,j)>600
                v(r,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if v(r,j)<50
                v(r,j)=50;
             end
            if v(r,j)>200
                v(r,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if v(r,j)<50
                v(r,j)=50;
             end
            if v(r,j)>160
                v(r,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if v(r,j)<20
                v(r,j)=20;
             end
            if v(r,j)>100
                v(r,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if v(r,j)<25
                v(r,j)=25;
             end
            if v(r,j)>125
                v(r,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if v(r,j)<50
                v(r,j)=50;
             end
            if v(r,j)>150
                v(r,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if v(r,j)<50
                v(r,j)=50;
             end
            if v(r,j)>200
                v(r,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if v(r,j)<30
                v(r,j)=30;
             end
            if v(r,j)>150
                v(r,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if v(r,j)<100
                v(r,j)=100;
             end
            if v(r,j)>300
                v(r,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if v(r,j)<150
                v(r,j)=150;
             end
            if v(r,j)>500
                v(r,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if v(r,j)<40
                v(r,j)=40;
             end
            if v(r,j)>160
                v(r,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if v(r,j)<20
                v(r,j)=20;
             end
            if v(r,j)>130
                v(r,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if v(r,j)<25
                v(r,j)=25;
             end
            if v(r,j)>185
                v(r,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if v(r,j)<20
                v(r,j)=20;
             end
            if v(r,j)>80
                v(r,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if v(r,j)<30
                v(r,j)=30;
             end
            if v(r,j)>85
                v(r,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if v(r,j)<30
                v(r,j)=30;
             end
            if v(r,j)>120
                v(r,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if v(r,j)<40
                v(r,j)=40;
             end
            if v(r,j)>120
                v(r,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if v(r,j)<30
                v(r,j)=30;
             end
            if v(r,j)>100
                v(r,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
     [Fnew,PL,PTotal]= f20_ELD_mobjective(v(r,:));
     % Update if the solution improves
     if Fnew <= Fitness(r)
        Positions(r,:)= v(r,:);
        Fitness(r)= Fnew;
     end
     if Fnew <= DOA_vMin
         DOA_theBestVct= v(r,:);
         DOA_vMin= Fnew;
           DOA_PL=PL;
        DOA_PTotal=PTotal;
     end 
   end
   DOA_Convergence_curve(t+1)= DOA_vMin; 
   [vMax maxIdx]= max(Fitness);
    survival= survival_rate( Fitness, DOA_vMin, vMax); % Section 2.2.4 Dingoes'survival rates
 end
%_____________________________________________________End DOA Algorithm]%
