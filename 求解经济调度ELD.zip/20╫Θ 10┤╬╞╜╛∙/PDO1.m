%_________________________________________________________________________
% Prairie Dogs Optimization source code demo version 
% Developed in MATLAB R2020b    
%  
% paper:
% Absalom E. Ezugwu, Jeffrey O. Agushaka, Laith Abualigah, Seyedali Mirjalili, Amir H Gandomi
% Prairie Dogs Optimization: A Nature-inspired Metaheuristic
%  
%  
% E-mails: EzugwuA@ukzn.ac.za                 Absalom E. Ezugwu
%          218088307@stu.ukzn.ac.za            Jeffrey O. Agushaka 
%           
%_________________________________________________________________________



function [PDOBest_PD,PDOPDBest_P,PDOConv,PDO_PL,PDO_PTotal]=PDO1(Dim,N,M_Iter,LB,UB,f20_ELD_mobjective)
PDO_PL=0;
PDO_PTotal=0;
PDOPDBest_P=zeros(1,Dim);           % best positions
PDOBest_PD=inf;                    % global best fitness
X=initializationPDO(N,Dim,UB,LB); %Initialize the positions of solution
Xnew=zeros(N,Dim);
PDOConv=zeros(1,M_Iter);               % Convergance array
M=Dim;                      %set number of coteries 

t=1;                         % starting iteration
rho=0.005;                   % account for individual PD difference
% eps                         %food source quality 
epsPD=0.1; 

% food source alarm
OBest=zeros(1,size(X,1));     % old fitness values
CBest=zeros(1,size(X,1));     % new fitness values

for i=1:size(X,1) 
 Flag_UB=X(i,:)>UB; % check if they exceed (up) the boundaries
 Flag_LB=X(i,:)<LB; % check if they exceed (down) the boundaries
 X(i,:)=(X(i,:).*(~(Flag_UB+Flag_LB)))+UB.*Flag_UB+LB.*Flag_LB;

    OBest(1,i)=f20_ELD_mobjective(X(i,:));   %Calculate the fitness values of solutions
        if OBest(1,i)<PDOBest_PD
            PDOBest_PD=OBest(1,i);
            PDOPDBest_P=X(i,:);
        end
end
  

while t<M_Iter+1  %Main loop %Update the Position of solutions
if mod(t,2)==0
             mu=-1;
else
             mu=1;
end
 
    DS=1.5*randn*(1-t/M_Iter)^(2*t/M_Iter)*mu;  % Digging strength
    PE=1.5*(1-t/M_Iter)^(2*t/M_Iter)*mu;  % Predator effect
    RL=levym(N,Dim,1.5);     % Levy random number vector
    TPD=repmat(PDOPDBest_P,N,1); %Top PD
    for i=1:N 
        for j=1:M  
                cpd=rand*((TPD(i,j)-X(randi([1 N]),j)))/((TPD(i,j))+eps);
                
                 P=rho+(X(i,j)-mean(X(i,:)))/(TPD(i,j)*(UB(j)-LB(j))+eps);
                eCB=PDOPDBest_P(1,j)*P;
                if (t<M_Iter/4)
                    Xnew(i,j)=PDOPDBest_P(1,j)-eCB*epsPD-cpd*RL(i,j);    
                elseif (t<2*M_Iter/4 && t>=M_Iter/4)
                    Xnew(i,j)=PDOPDBest_P(1,j)*X(randi([1 N]),j)*DS*RL(i,j);
                elseif (t<3*M_Iter/4 && t>=2*M_Iter/4)
                    Xnew(i,j)=PDOPDBest_P(1,j)*PE*rand;
                else
                    Xnew(i,j)=PDOPDBest_P(1,j)-eCB*eps-cpd*rand;
                end
        end
            
%             Flag_UB=Xnew(i,:)>UB; % check if they exceed (up) the boundaries
%             Flag_LB=Xnew(i,:)<LB; % check if they exceed (down) the boundaries
%             Xnew(i,:)=(Xnew(i,:).*(~(Flag_UB+Flag_LB)))+UB.*Flag_UB+LB.*Flag_LB;
        for j=1:1
            if Xnew(i,j)<150
                Xnew(i,j)=150;
            end
            if Xnew(i,j)>600
                Xnew(i,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>200
                Xnew(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>160
                Xnew(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>100
                Xnew(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if Xnew(i,j)<25
                Xnew(i,j)=25;
             end
            if Xnew(i,j)>125
                Xnew(i,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>150
                Xnew(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if Xnew(i,j)<50
                Xnew(i,j)=50;
             end
            if Xnew(i,j)>200
                Xnew(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>150
                Xnew(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if Xnew(i,j)<100
                Xnew(i,j)=100;
             end
            if Xnew(i,j)>300
                Xnew(i,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if Xnew(i,j)<150
                Xnew(i,j)=150;
             end
            if Xnew(i,j)>500
                Xnew(i,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if Xnew(i,j)<40
                Xnew(i,j)=40;
             end
            if Xnew(i,j)>160
                Xnew(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>130
                Xnew(i,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if Xnew(i,j)<25
                Xnew(i,j)=25;
             end
            if Xnew(i,j)>185
                Xnew(i,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if Xnew(i,j)<20
                Xnew(i,j)=20;
             end
            if Xnew(i,j)>80
                Xnew(i,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>85
                Xnew(i,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>120
                Xnew(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if Xnew(i,j)<40
                Xnew(i,j)=40;
             end
            if Xnew(i,j)>120
                Xnew(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if Xnew(i,j)<30
                Xnew(i,j)=30;
             end
            if Xnew(i,j)>100
                Xnew(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
           [CBest(1,i),PL,PTotal]=f20_ELD_mobjective(Xnew(i,:));
            if CBest(1,i)<OBest(1,i)
                X(i,:)=Xnew(i,:);
                OBest(1,i)=CBest(1,i);
            end
            if OBest(1,i)<PDOBest_PD
                PDOBest_PD=OBest(1,i);
                PDOPDBest_P=X(i,:);
         PDO_PL=PL;
        PDO_PTotal=PTotal;
            end
    end
  
    PDOConv(t)=PDOBest_PD;  %Update the convergence curve

    if mod(t,50)==0  %Print the best details after every 50 iterations
        display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(PDOBest_PD)]);
    end
     t=t+1;
end
end