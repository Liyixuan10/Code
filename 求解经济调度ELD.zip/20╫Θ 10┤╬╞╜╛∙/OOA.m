



%%% Designed and Developed by Pavel Trojovský and Mohammad Dehghani %%%


function[OOABest_score,OOABest_pos,OOA_curve,OOA_PL,OOA_PTotal]=OOA(N,M_Iter,LB,UB,Dim,f20_ELD_mobjective)
LB=ones(1,Dim).*(LB);                              % Lower limit for variables
UB=ones(1,Dim).*(UB);                              % Upper limit for variables
OOA_PL=0;
OOA_PTotal=0;
%% INITIALIZATION
for i=1:Dim
    X(:,i) = LB(i)+rand(N,1).*(UB(i) - LB(i));                          % Initial population
end

for i =1:N
    L=X(i,:);
    fit(i)=f20_ELD_mobjective(L);
end
%%

for t=1:M_Iter  % algorithm iteration
    
    %%  update: BEST proposed solution
    [Fbest , blocation]=min(fit);
    
    if t==1
        xbest=X(blocation,:);                                           % Optimal location
        fbest=Fbest;                                           % The optimization objective function
    elseif Fbest<fbest
        fbest=Fbest;
        xbest=X(blocation,:);
    end
    %%
    %%
    for i=1:N
        %% Phase 1: : POSITION IDENTIFICATION AND HUNTING THE FISH (EXPLORATION)
        fish_position=find(fit<fit(i));% Eq(4)
        if size(fish_position,2)==0
            selected_fish=xbest;
        else
            if rand <0.5
                selected_fish=xbest;
            else
                k=randperm(size(fish_position,2),1);
                selected_fish=X(fish_position(k));
            end
        end
        %
        I=round(1+rand);
        X_new_P1=X(i,:)+rand(1,1).*(selected_fish-I.*X(i,:));%Eq(5)
        X_new_P1 = max(X_new_P1,LB);X_new_P1 = min(X_new_P1,UB);
        
        % update position based on Eq (6)
        L=X_new_P1;
        [fit_new_P1,PL,PTotal]=f20_ELD_mobjective(L);
        if fit_new_P1<fit(i)
            X(i,:) = X_new_P1;
            fit(i) = fit_new_P1;
                                     OOA_PL=PL;
        OOA_PTotal=PTotal;
        end
        %% END Phase 1
        
        %%
        %% PHASE 2: CARRYING THE FISH TO THE SUITABLE POSITION (EXPLOITATION)
        X_new_P1=X(i,:)+(LB+rand*(UB-LB))/t;%Eq(7)
        X_new_P1 = max(X_new_P1,LB);X_new_P1 = min(X_new_P1,UB);
        for j=1:1
            if L(i,j)<150
                X_new_P1(i,j)=150;
            end
            if L(i,j)>600
                L(i,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if L(i,j)<50
                L(i,j)=50;
             end
            if L(i,j)>200
                L(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if L(i,j)<50
                L(i,j)=50;
             end
            if L(i,j)>160
                L(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if L(i,j)<20
                L(i,j)=20;
             end
            if L(i,j)>100
                L(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if L(i,j)<25
                L(i,j)=25;
             end
            if L(i,j)>125
                L(i,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if L(i,j)<50
                L(i,j)=50;
             end
            if L(i,j)>150
                L(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if L(i,j)<50
                L(i,j)=50;
             end
            if L(i,j)>200
                L(i,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if L(i,j)<30
                L(i,j)=30;
             end
            if L(i,j)>150
                L(i,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if L(i,j)<100
                L(i,j)=100;
             end
            if L(i,j)>300
                L(i,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if L(i,j)<150
                L(i,j)=150;
             end
            if L(i,j)>500
                L(i,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if L(i,j)<40
                L(i,j)=40;
             end
            if L(i,j)>160
                L(i,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if L(i,j)<20
                L(i,j)=20;
             end
            if L(i,j)>130
                L(i,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if L(i,j)<25
                L(i,j)=25;
             end
            if L(i,j)>185
                L(i,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if L(i,j)<20
                L(i,j)=20;
             end
            if L(i,j)>80
                L(i,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if L(i,j)<30
                L(i,j)=30;
             end
            if L(i,j)>85
                L(i,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if L(i,j)<30
                L(i,j)=30;
             end
            if L(i,j)>120
                L(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if L(i,j)<40
                L(i,j)=40;
             end
            if L(i,j)>120
                L(i,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if L(i,j)<30
                L(i,j)=30;
             end
            if L(i,j)>100
                L(i,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
        % update position based on Eq (8)
        L=X_new_P1;
        [fit_new_P1,PL,PTotal]=f20_ELD_mobjective(L);
        if fit_new_P1<fit(i)
            X(i,:) = X_new_P1;
            fit(i) = fit_new_P1;
                                                 OOA_PL=PL;
        OOA_PTotal=PTotal;
        end
        %% END Phase 2
        %%
    end
    %%
    
    best_so_far(t)=fbest;
    average(t) = mean (fit);
    
end
OOABest_score=fbest;
OOABest_pos=xbest;
OOA_curve=best_so_far;
end

