clear all 
clc
N=20; 
Dim=20;
M_Iter=1000; 
n1=[];
n2=[];
 n3=[];
n4=[];
 n5=[];
n6=[];
% n7=[];
% n8=[];
LB=[150,50,50,50,50,20,25,50,50,30,100,150,40,20,25,20, 30,30,40,30];
UB=[600,200,200,200,160,100,125,150,200,150,300,500,160,130,185,80,85,120,120,100];
for i=1:30
   [LSCAOABest_FF,LSCAOABest_P,LSCAOA_Conv_curve,LSCAOA_PL,LSCAOA_PTotal]=LSCAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
[BATBestPositions6,BATfmin6,BATCNVG6,BAT_PL,BAT_PTotal]=BAT(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
[GOATop_gazelle_fit,GOATop_gazelle_pos,GOAConvergence_curve,GOA_PL,GOA_PTotal]=GOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
[PDOBest_PD,PDOPDBest_P,PDOConv,PDO_PL,PDO_PTotal]=PDO1(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
[RSABest_F,RSABest_P,RSACNVG4,RSA_PL,RSA_PTotal]=RSA(N,M_Iter,LB,UB,Dim,@f20_ELD_mobjective)
  [DOA_vMin,DOA_theBestVct,DOA_Convergence_curve,DOA_PL,DOA_PTotal]=DOA(N,M_Iter,LB,UB,Dim,@f20_ELD_mobjective)
%[OOABest_score,OOABest_pos,OOA_curve,OOA_PL,OOA_PTotal]=OOA(N,M_Iter,LB,UB,Dim,@f20_ELD_mobjective)
  %  [AOABest_FF,AOABest_P,AOAConv_curve,AOA_PL,AOA_PTotal]=AOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
%     [TAOABest_FF,TAOABest_P,TAOA_Conv_curve,TAOA_PL,TAOA_PTotal]=TAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
%     [PAOABest_FF,PAOABest_P,PAOA_Conv_curve,PAOA_PL,PAOA_PTotal]=PAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
%     [LAOABest_FF,LAOABest_P,LAOA_Conv_curve,LAOA_PL,LAOA_PTotal]=LAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
%     [GAOABest_FF,GAOABest_P,GAOA_Conv_curve,GAOA_PL,GAOA_PTotal]=GAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
%     [SAOABest_FF,SAOABest_P,SAOA_Conv_curve,SAOA_PL,SAOA_PTotal]=SAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
%     [CAOABest_FF,CAOABest_P,CAOA_Conv_curve,CAOA_PL,CAOA_PTotal]=CAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
%     [SGAOABest_FF,SGAOABest_P,SGAOA_Conv_curve,SGAOA_PL,SGAOA_PTotal]=SGAOA(Dim,N,M_Iter,LB,UB,@f20_ELD_mobjective)
    
 
 
c1(i,:)=LSCAOA_Conv_curve;
c2(i,:)=BATCNVG6;
c3(i,:)=GOAConvergence_curve;
c4(i,:)=PDOConv;
 c5(i,:)=RSACNVG4;
 c6(i,:)=DOA_Convergence_curve;
% c7(i,:)=CAOA_Conv_curve;
% c8(i,:)=SGAOA_Conv_curve;

n1(end+1)=LSCAOABest_FF;
n2(end+1)=BATfmin6;
 n3(end+1)=GOATop_gazelle_fit;
 n4(end+1)=PDOBest_PD;
 n5(end+1)=RSABest_F;
 n6(end+1)=DOA_vMin;
% n7(end+1)=CAOABest_FF;
% n8(end+1)=SGAOABest_FF;

end
ave1=mean(n1);
ave2=mean(n2);
ave3=mean(n3);
 ave4=mean(n4);
 ave5=mean(n5);
ave6=mean(n6);
% ave7=mean(n7);
% ave8=mean(n8);

LSCAOA_Conv_curve=mean(c1,1);
BATCNVG6=mean(c2,1);
GOAConvergence_curve=mean(c3,1);
PDOConv=mean(c4,1);
RSACNVG4=mean(c5,1);
DOA_Convergence_curve=mean(c6,1);
% SAOA_Conv_curve=mean(c6,1);
% CAOA_Conv_curve=mean(c7,1);
% SGAOA_Conv_curve=mean(c8,1);
% aave1=[ave1 ave2 ave3 ave4 ave5 ave6 ave7 ave8];

semilogy(LSCAOA_Conv_curve,'DisplayName','AOA','color','r','Marker','+','markerindices',(1:100:1000),'LineWidth',1)
hold on
semilogy(BATCNVG6,'DisplayName','BAT','color','k','Marker','o','markerindices',(1:100:1000),'LineWidth',1)
hold on
  semilogy(GOAConvergence_curve,'DisplayName','GOA','color','b','Marker','*','markerindices',(1:100:1000),'LineWidth',1)
  hold on
 semilogy(PDOConv,'DisplayName','PDO','Color','c','Marker','.','markerindices',(1:100:1000),'LineWidth',1)
 hold on
 semilogy(RSACNVG4,'DisplayName','RSA','Color','m','Marker','x','markerindices',(1:100:1000),'LineWidth',1)
 hold on
  semilogy(DOA_Convergence_curve,'DisplayName','DOA','Color','#D95319','Marker','s','markerindices',(1:100:1000),'LineWidth',1)
  hold on
% semilogy(CAOA_Conv_curve,'DisplayName','CAOA','Color','k','Marker','d','markerindices',(1:100:1000),'LineWidth',1)
% hold on
% semilogy(SGAOA_Conv_curve,'DisplayName','SGAOA','Color','#77AC30','Marker','diamond','markerindices',(1:100:1000),'LineWidth',1)
% hold on
axis tight
legend('LSCAOA','BAT','GOA','PDO','RSA','DOA')%,'HGOA1','HGOA2','HGOA3','HGOA4','BA','HHO','GGOA','HGOA''GOA',


