function  [BATBestPositions6,BATfmin6,BATCNVG6,BAT_PL,BAT_PTotal]=BAT(Dim,N,M_Iter,LB,UB,f20_ELD_mobjective)
%%
% Max_iter=20;            % maximum generations
% N=10;                   %BAT numbers
% dim=10;
% lb=-2*zeros(1,dim);
% ub=2*ones(1,dim);
Fmax=2;                 %maximum frequency
Fmin=0;                 %minimum frequency
A=rand(N,1);            %loudness for each BAT
r=rand(N,1);            %pulse emission rate for each BAT
alpha=0.5;              %constant for loudness update
gamma=0.5;              %constant for emission rate update
ro=0.001;                 %initial pulse emission rate
% Initializing arrays
F=zeros(N,1);           % Frequency
v=zeros(N,Dim);           % Velocities
% Initialize the population
x=initialization(N,Dim,UB,LB);
BATCNVG6=zeros(1,M_Iter);
BAT_PL=0;
BAT_PTotal=0;
%calculate the initial solution for initial positions
for ii=1:N
    fitness(ii)=f20_ELD_mobjective(x(ii,:));
end
[BATfmin6,index]=min(fitness);          %find the initial best fitness value,
bestsol=x(index,:);                 %find the initial best solution for best fitness value
%%
iter=1;             % start the loop counter
while iter<=M_Iter                               %start the loop for iterations
    for ii=1:size(x)
        F(ii)=Fmin+(Fmax-Fmin)*rand;              %randomly chose the frequency
        v(ii,:)=v(ii,:)+(x(ii,:)-bestsol)*F(ii);  %update the velocity
        x(ii,:)=x(ii,:)+v(ii,:);                  %update the BAT position
        %         x(ii,:)=round(x(ii,:));
        % Apply simple bounds/limits
%         Flag4up=x(ii,:)>UB;
%         Flag4low=x(ii,:)<LB;
%         x(ii,:)=(x(ii,:).*(~(Flag4up+Flag4low)))+UB.*Flag4up+LB.*Flag4low;
        %check the condition with r
                       for j=1:1
            if x(ii,j)<150
                x(ii,j)=150;
            end
            if x(ii,j)>600
                x(ii,j)=600;
            end
             %x(i,j)=round(x(i,j));
         end
         for j=2:4
             if x(ii,j)<50
                x(ii,j)=50;
             end
            if x(ii,j)>200
                x(ii,j)=200;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=5:5
             if x(ii,j)<50
                x(ii,j)=50;
             end
            if x(ii,j)>160
                x(ii,j)=160;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=6:6
             if x(ii,j)<20
                x(ii,j)=20;
             end
            if x(ii,j)>100
                x(ii,j)=100;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=7:7
             if x(ii,j)<25
                x(ii,j)=25;
             end
            if x(ii,j)>125
                x(ii,j)=125;
            end
            %x(i,j)=round(x(i,j));
         end
         for j=8:8
             if x(ii,j)<50
                x(ii,j)=50;
             end
            if x(ii,j)>150
                x(ii,j)=150;
            end
            %x(i,j)=round(x(i,j));
         end
           for j=9:9
             if x(ii,j)<50
                x(ii,j)=50;
             end
            if x(ii,j)>200
                x(ii,j)=200;
            end
            %x(i,j)=round(x(i,j));
           end
           for j=10:10
             if x(ii,j)<30
                x(ii,j)=30;
             end
            if x(ii,j)>150
                x(ii,j)=150;
            end
            %x(i,j)=round(x(i,j));
           end
                  for j=11:11
             if x(ii,j)<100
                x(ii,j)=100;
             end
            if x(ii,j)>300
                x(ii,j)=300;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=12:12
             if x(ii,j)<150
                x(ii,j)=150;
             end
            if x(ii,j)>500
                x(ii,j)=500;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=13:13
             if x(ii,j)<40
                x(ii,j)=40;
             end
            if x(ii,j)>160
                x(ii,j)=160;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=14:14
             if x(ii,j)<20
                x(ii,j)=20;
             end
            if x(ii,j)>130
                x(ii,j)=130;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=15:15
             if x(ii,j)<25
                x(ii,j)=25;
             end
            if x(ii,j)>185
                x(ii,j)=185;
            end
            %x(i,j)=round(x(i,j));
                  end
             for j=16:16
             if x(ii,j)<20
                x(ii,j)=20;
             end
            if x(ii,j)>80
                x(ii,j)=80;
            end
            %x(i,j)=round(x(i,j));
             end
              for j=17:17
             if x(ii,j)<30
                x(ii,j)=30;
             end
            if x(ii,j)>85
                x(ii,j)=85;
            end
            %x(i,j)=round(x(i,j));
              end
                  for j=18:18
             if x(ii,j)<30
                x(ii,j)=30;
             end
            if x(ii,j)>120
                x(ii,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=19:19
             if x(ii,j)<40
                x(ii,j)=40;
             end
            if x(ii,j)>120
                x(ii,j)=120;
            end
            %x(i,j)=round(x(i,j));
                  end
                  for j=20:20
             if x(ii,j)<30
                x(ii,j)=30;
             end
            if x(ii,j)>100
                x(ii,j)=100;
            end
        if rand>r(ii)
            % The factor 0.001 limits the step sizes of random walks
            %               x(ii,:)=bestsol+0.001*randn(1,dim);
            eps=-1+(1-(-1))*rand;
            x(ii,:)=bestsol+eps*mean(A);
        end
       [fitnessnew,PL,PTotal]=f20_ELD_mobjective(x(ii,:));  % calculate the objective function
        % Update if the solution improves, or not too loud
        if (fitnessnew<=fitness(ii)) && (rand<A(ii)) ,
            
            fitness(ii)=fitnessnew;
            A(ii)=alpha*A(ii);
            r(ii)=ro*(1-exp(-gamma*iter));
        end
        if fitnessnew<=BATfmin6
            bestsol=x(ii,:);
            BATfmin6=fitnessnew;
                                    BAT_PL=PL;
       BAT_PTotal=PTotal;
        end
        
    end
    BATCNVG6(iter)=BATfmin6;
    
    iter=iter+1;                                  % update the while loop counter
end
%
[bestfit]=(BATfmin6);
BATBestPositions6=bestsol;
end
